const V = 'ktc-lms-v1';
const SHELL = ['./', 'index.html', 'style.css', 'js/core.js', 'js/app.js', 'js/vendor/jszip.min.js', 'manifest.webmanifest', 'assets/logo.png', 'assets/icon-192.png', 'assets/icon-512.png'];
self.addEventListener('install', e => { self.skipWaiting(); e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).catch(() => { })); });
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => clients.claim())));
function idbGet(key) {
  return new Promise((res, rej) => {
    const r = indexedDB.open('ktc-lms');
    r.onsuccess = () => { try { const q = r.result.transaction('files').objectStore('files').get(key); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); } catch (e) { rej(e); } };
    r.onerror = () => rej(r.error);
  });
}
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (u.origin !== location.origin || e.request.method !== 'GET') return;
  const i = u.pathname.indexOf('/__pkg/');
  if (i >= 0) {
    e.respondWith((async () => {
      const rest = u.pathname.slice(i + 7), slash = rest.indexOf('/');
      const id = rest.slice(0, slash), path = decodeURIComponent(rest.slice(slash + 1));
      const f = await idbGet('pkg:' + id + ':' + path);
      if (!f) return new Response('Not found: ' + path, { status: 404 });
      return new Response(f.blob, { headers: { 'Content-Type': f.type || 'application/octet-stream' } });
    })()); return;
  }
  e.respondWith(fetch(e.request).then(r => { const c = r.clone(); caches.open(V).then(ch => ch.put(e.request, c)); return r; }).catch(() => caches.match(e.request)));
});
