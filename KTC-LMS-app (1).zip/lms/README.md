# KTC Learning Hub — mobile LMS (PWA)

Run: serve this folder over https or http://localhost (needed for install + SCORM engine), e.g.
    python3 -m http.server 8080      → open http://localhost:8080
Host on any static host (Netlify, GitHub Pages, Railway, S3…) for real use; on a phone use
"Add to Home Screen" to install it like an app.

Super Admin login: ID  Learning@admin  /  password  Learning@admin  (change it from Profile after first sign-in).

Roles: Super Admin (everything incl. admins & branding) · Admin (courses, learners, assignments, reports) · Learner.
Admins/Super Admins switch Admin ⇄ Learner view with the button in the header.
Bulk upload CSV templates are in bulk-templates/ (also downloadable inside the app: More → Bulk upload).
