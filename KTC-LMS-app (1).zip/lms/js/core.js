'use strict';
/* ===== Utilities ===== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = (p = '') => p + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const addDays = (n, from) => { const d = from ? new Date(from + 'T00:00') : new Date(); d.setDate(d.getDate() + n); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const fmtDate = d => { if (!d) return '—'; const x = new Date(d.length === 10 ? d + 'T00:00' : d); return String(x.getDate()).padStart(2, '0') + '-' + ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][x.getMonth()] + '-' + x.getFullYear(); };
const fmtSize = n => n > 1e6 ? (n / 1e6).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1e3)) + ' KB';
const sleep = ms => new Promise(r => setTimeout(r, ms));

const MIME = { mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', mkv: 'video/x-matroska', ogv: 'video/ogg', m4v: 'video/mp4', '3gp': 'video/3gpp', avi: 'video/x-msvideo', wmv: 'video/x-ms-wmv', flv: 'video/x-flv', mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', m4a: 'audio/mp4', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', bmp: 'image/bmp', pdf: 'application/pdf', html: 'text/html', htm: 'text/html', css: 'text/css', js: 'text/javascript', json: 'application/json', xml: 'application/xml', txt: 'text/plain', woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', swf: 'application/x-shockwave-flash', ico: 'image/x-icon', csv: 'text/csv' };
const extOf = n => (String(n).split('?')[0].split('.').pop() || '').toLowerCase();
const mimeOf = n => MIME[extOf(n)] || 'application/octet-stream';
const KIND_BY_EXT = { video: 'mp4 webm mov mkv ogv m4v 3gp avi wmv flv', audio: 'mp3 wav ogg m4a', image: 'jpg jpeg png gif webp svg bmp', pdf: 'pdf', ppt: 'ppt pptx pps ppsx potx', doc: 'doc docx xls xlsx csv odt ods', html: 'html htm', zip: 'zip' };
function kindOf(name) { const e = extOf(name); for (const k in KIND_BY_EXT) if (KIND_BY_EXT[k].split(' ').includes(e)) return k; return 'doc'; }
const ytId = u => { const m = String(u).match(/(?:youtu\.be\/|v=|embed\/|shorts\/|live\/)([\w-]{11})/); return m ? m[1] : (/^[\w-]{11}$/.test(u) ? u : null); };

function parseCSV(t) {
  const rows = []; let r = [], c = '', q = false; t = t.replace(/^﻿/, '');
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (q) { if (ch === '"') { if (t[i + 1] === '"') { c += '"'; i++; } else q = false; } else c += ch; }
    else if (ch === '"') q = true;
    else if (ch === ',') { r.push(c); c = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && t[i + 1] === '\n') i++; r.push(c); c = ''; rows.push(r); r = []; }
    else c += ch;
  }
  if (c !== '' || r.length) { r.push(c); rows.push(r); }
  return rows.filter(r => r.some(x => x.trim() !== ''));
}
function csvToObjs(t) {
  const rows = parseCSV(t); if (!rows.length) return [];
  const h = rows.shift().map(x => x.trim().toLowerCase().replace(/[\s-]+/g, '_'));
  return rows.map((r, i) => { const o = { _row: i + 2 }; h.forEach((k, j) => o[k] = (r[j] ?? '').trim()); return o; });
}
const toCSV = rows => rows.map(r => r.map(v => { v = String(v ?? ''); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(',')).join('\r\n');
function download(name, data, type = 'text/plain') {
  const b = data instanceof Blob ? data : new Blob([data], { type });
  const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
}
async function hashPw(pw) {
  const s = 'ktc-lms|' + pw;
  if (crypto && crypto.subtle) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); }
  let h = 2166136261; for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return 'f' + (h >>> 0).toString(16);
}

/* ===== IndexedDB ===== */
const STORES = ['users', 'courses', 'assignments', 'progress', 'settings', 'files', 'audit', 'certs'];
const DB = {
  db: null,
  open() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('ktc-lms', 1);
      r.onupgradeneeded = () => { for (const s of STORES) if (!r.result.objectStoreNames.contains(s)) r.result.createObjectStore(s, { keyPath: 'id' }); };
      r.onsuccess = () => { this.db = r.result; res(); }; r.onerror = () => rej(r.error);
    });
  },
  st(s, m = 'readonly') { return this.db.transaction(s, m).objectStore(s); },
  rq(r) { return new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); },
  all(s) { return this.rq(this.st(s).getAll()); },
  get(s, k) { return this.rq(this.st(s).get(k)); },
  put(s, v) { return this.rq(this.st(s, 'readwrite').put(v)); },
  del(s, k) { return this.rq(this.st(s, 'readwrite').delete(k)); },
  clear(s) { return this.rq(this.st(s, 'readwrite').clear()); },
  keys(s) { return this.rq(this.st(s).getAllKeys()); },
};

/* ===== State ===== */
const DEFAULTS = {
  id: 'main', appName: 'KTC Learning Hub', orgName: 'KTC India Limited', deptName: 'Learning & Development',
  primary: '#182B70', accent: '#E8A317', theme: 'light', radius: 14, font: 'system', logoFileId: null,
  certPrefix: 'KTC-CERT', certColor: '#182B70', signatory: 'Authorized Signatory', signatoryTitle: 'L&D / Training',
  sealLabel: 'OFFICIAL SEAL / SIGNATURE', passMark: 70, defaultPassword: 'Welcome@123', selfSignup: false,
};
const S = { users: [], courses: [], assignments: [], progress: [], certs: [], audit: [], settings: { ...DEFAULTS } };
async function loadAll() {
  for (const s of ['users', 'courses', 'assignments', 'progress', 'certs', 'audit']) S[s] = await DB.all(s);
  S.settings = { ...DEFAULTS, ...((await DB.get('settings', 'main')) || {}) };
}
function save(store, obj) { const a = S[store], i = a.findIndex(o => o.id === obj.id); if (i < 0) a.push(obj); else a[i] = obj; return DB.put(store, obj); }
function remove(store, id) { S[store] = S[store].filter(o => o.id !== id); return DB.del(store, id); }
async function saveSettings(patch) { S.settings = { ...S.settings, ...patch }; await DB.put('settings', S.settings); bc.postMessage('sync'); }
const bc = ('BroadcastChannel' in self) ? new BroadcastChannel('ktc-lms') : { postMessage() { }, onmessage: null };
async function log(action, detail = '') {
  const u = typeof me === 'function' ? me() : null;
  const e = { id: uid('a'), at: new Date().toISOString(), by: u ? u.name : 'system', role: u ? u.role : '', action, detail };
  S.audit.push(e); if (S.audit.length > 600) { const old = S.audit.shift(); DB.del('audit', old.id); } DB.put('audit', e);
}

/* ===== Files (blobs) ===== */
const urlCache = {};
async function putFile(blob, name) { const id = uid('f'); await DB.put('files', { id, blob, name, size: blob.size, type: blob.type || mimeOf(name) }); return id; }
async function getFile(id) { return id ? DB.get('files', id) : null; }
async function fileURL(id) { if (!id) return null; if (urlCache[id]) return urlCache[id]; const f = await getFile(id); if (!f) return null; return urlCache[id] = URL.createObjectURL(f.blob); }
async function gcFiles() {
  const used = new Set();
  S.courses.forEach(c => { if (c.thumbFileId) used.add(c.thumbFileId); (c.lessons || []).forEach(l => { if (l.fileId) used.add(l.fileId); if (l.pkgId) used.add('pkg:' + l.pkgId); }); });
  if (S.settings.logoFileId) used.add(S.settings.logoFileId);
  for (const k of await DB.keys('files')) {
    if (typeof k === 'string' && k.startsWith('pkg:')) { if (!used.has(k.split(':').slice(0, 2).join(':'))) { await DB.del('files', k); } }
    else if (!used.has(k)) { await DB.del('files', k); delete urlCache[k]; }
  }
}
async function importZip(file) {
  const zip = await JSZip.loadAsync(file); const pkgId = uid('p'); const names = Object.keys(zip.files).filter(n => !zip.files[n].dir);
  if (!names.length) throw new Error('The ZIP file is empty');
  const man = names.find(n => /(^|\/)imsmanifest\.xml$/i.test(n)); let launch = null, scorm = null, base = '';
  if (man) {
    const xml = new DOMParser().parseFromString(await zip.file(man).async('string'), 'application/xml');
    base = man.includes('/') ? man.replace(/[^/]+$/, '') : '';
    const ver = (xml.getElementsByTagName('schemaversion')[0]?.textContent || '').trim();
    scorm = /1\.2/.test(ver) || !ver ? '1.2' : '2004';
    if (/2004|CAM 1\.3/.test(ver)) scorm = '2004';
    const res = {}; for (const r of xml.getElementsByTagName('resource')) res[r.getAttribute('identifier')] = r;
    const item = [...xml.getElementsByTagName('item')].find(i => i.getAttribute('identifierref'));
    let r = item ? res[item.getAttribute('identifierref')] : null; if (!r) r = Object.values(res).find(x => x.getAttribute('href'));
    if (r) { const href = r.getAttribute('href'); const xb = r.getAttribute('xml:base') || ''; launch = base + xb + href; }
  }
  if (!launch) launch = names.find(n => /(^|\/)index\.html?$/i.test(n)) || names.find(n => /\.html?$/i.test(n));
  if (!launch) throw new Error('No imsmanifest.xml or index.html found in the ZIP');
  for (const n of names) { const data = await zip.file(n).async('blob'); await DB.put('files', { id: 'pkg:' + pkgId + ':' + n, blob: new Blob([data], { type: mimeOf(n) }), name: n, size: data.size, type: mimeOf(n) }); }
  return { pkgId, launch: launch.split('?')[0], launchQuery: (launch.split('?')[1] || ''), scorm };
}
const pkgURL = l => new URL('__pkg/' + l.pkgId + '/' + l.launch.split('/').map(encodeURIComponent).join('/') + (l.launchQuery ? '?' + l.launchQuery : ''), location.href).href;

/* ===== Certificate rendering (replicates the supplied KTC template) ===== */
function loadImg(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; }); }
const CERT_W = 1600, CERT_H = 900, U = 1.6; // template units: 1000 units = slide width
async function drawCertificate(canvas, c, logoSrc) {
  canvas.width = CERT_W; canvas.height = CERT_H; const g = canvas.getContext('2d'); const navy = c.color || '#182B70', dark = '#232323', grey = '#969696';
  const SANS = '"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif', SERIF = 'Georgia,"Times New Roman",serif';
  g.fillStyle = '#F7F8FC'; g.fillRect(0, 0, CERT_W, CERT_H);
  g.strokeStyle = navy; g.lineWidth = 3; g.strokeRect(13 * U, 13 * U, 972 * U, 535 * U);
  g.lineWidth = 1.5; g.strokeRect(22 * U, 22 * U, 954 * U, 517 * U);
  try { const im = await loadImg(logoSrc); const bx = 48 * U, by = 41 * U, bw = 172 * U, bh = 84 * U, r = Math.min(bw / im.width, bh / im.height); g.drawImage(im, bx, by + (bh - im.height * r) / 2, im.width * r, im.height * r); } catch (e) { }
  const text = (t, cx, cy, font, color, maxW, wt = '', align = 'center') => {
    let px = parseInt(font); g.fillStyle = color; g.textAlign = align; g.textBaseline = 'middle';
    do { g.font = `${wt} ${px}px ${font.slice(font.indexOf(' ') + 1)}`; px -= 1; } while (g.measureText(t).width > maxW && px > 12);
    g.fillText(t, cx, cy);
  };
  text('CERTIFICATE OF COMPLETION', 502 * U, 68 * U, '47px ' + SANS, navy, 540 * U, 'bold');
  text('This certificate is proudly presented to', 500 * U, 106 * U, '23px ' + SANS, dark, 513 * U);
  text(c.name.toUpperCase(), 500 * U, 157 * U, '52px ' + SERIF, navy, 780 * U, 'bold');
  g.fillStyle = grey; g.fillRect(232 * U, 189 * U, 532 * U, 1.5);
  text('has successfully completed the training course', 500 * U, 241 * U, '25px ' + SANS, dark, 700 * U);
  text(c.course, 500 * U, 284 * U, '40px ' + SANS, navy, 780 * U, 'bold');
  text(c.org + ' | ' + c.dept, 500 * U, 325 * U, '20px ' + SANS, dark, 700 * U);
  const boxes = [[75, 202, 'Employee ID', c.empId || '—'], [311, 202, 'Completion Date', c.date], [547, 180, 'Certificate ID', c.certNo], [750, 172, 'Score / Status', c.score]];
  for (const [x, w, label, val] of boxes) {
    g.save(); g.shadowColor = 'rgba(0,0,0,.22)'; g.shadowBlur = 12; g.shadowOffsetY = 5; g.fillStyle = '#fff'; g.strokeStyle = grey; g.lineWidth = 1.5;
    g.beginPath(); g.roundRect(x * U, 356 * U, w * U, 67 * U, 18); g.fill(); g.restore(); g.stroke();
    text(label, (x + w / 2) * U, 389 * U, '16px ' + SANS, navy, (w - 14) * U, 'bold'); text(val, (x + w / 2) * U, 411 * U, '16px ' + SANS, dark, (w - 14) * U);
  }
  const sig = [[150, c.name, 'Learner'], [420, c.signatory, c.signatoryTitle], [675, c.sealLabel, c.org]];
  for (const [x, a, b] of sig) {
    g.fillStyle = dark; g.fillRect(x * U, 450 * U, 187 * U, 1.5);
    text(a, (x + 93.5) * U, 466 * U, '17px ' + SANS, dark, 187 * U, 'bold'); text(b, (x + 93.5) * U, 486 * U, '16px ' + SANS, navy, 187 * U);
  }
}
function canvasToPdf(canvas) {
  const jpg = atob(canvas.toDataURL('image/jpeg', 0.93).split(',')[1]); const img = new Uint8Array(jpg.length); for (let i = 0; i < jpg.length; i++) img[i] = jpg.charCodeAt(i);
  const enc = new TextEncoder(), parts = [], offs = []; let len = 0;
  const add = d => { const b = typeof d === 'string' ? enc.encode(d) : d; parts.push(b); len += b.length; };
  const obj = (n, body) => { offs[n] = len; add(`${n} 0 obj\n${body}\nendobj\n`); };
  add('%PDF-1.4\n');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>'); obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  obj(3, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 960 540] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>');
  offs[4] = len; add(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${canvas.width} /Height ${canvas.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.length} >>\nstream\n`); add(img); add('\nendstream\nendobj\n');
  const cs = 'q 960 0 0 540 0 0 cm /Im0 Do Q'; obj(5, `<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`);
  const xr = len; add('xref\n0 6\n0000000000 65535 f \n'); for (let i = 1; i <= 5; i++) add(String(offs[i]).padStart(10, '0') + ' 00000 n \n');
  add(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xr}\n%%EOF`);
  return new Blob(parts, { type: 'application/pdf' });
}

/* ===== PPTX viewer (basic renderer: text, shapes, pictures) ===== */
async function renderPptx(blob, el, startIdx = 0, onSlide) {
  const zip = await JSZip.loadAsync(blob), P = new DOMParser();
  const X = async p => { const f = zip.file(p); return f ? P.parseFromString(await f.async('string'), 'application/xml') : null; };
  const pres = await X('ppt/presentation.xml'); if (!pres) throw new Error('Not a valid PPTX');
  const sz = pres.getElementsByTagName('p:sldSz')[0], W = +sz.getAttribute('cx'), H = +sz.getAttribute('cy');
  const rl = await X('ppt/_rels/presentation.xml.rels'), rm = {}; for (const r of rl.getElementsByTagName('Relationship')) rm[r.getAttribute('Id')] = r.getAttribute('Target');
  const slides = [...pres.getElementsByTagName('p:sldId')].map(s => 'ppt/' + rm[s.getAttribute('r:id')].replace(/^\/?(ppt\/)?/, ''));
  const wpt = W / 12700, q = (n, tag) => n.getElementsByTagName(tag);
  const colorOf = n => { const f = n && [...n.children].find(c => c.localName === 'solidFill'); const c = f && f.children[0]; return c && c.localName === 'srgbClr' ? '#' + c.getAttribute('val') : null; };
  const media = {}; const mediaURL = async p => media[p] || (media[p] = zip.file(p) ? URL.createObjectURL(new Blob([await zip.file(p).async('uint8array')], { type: mimeOf(p) })) : '');
  const out = [];
  for (const sp of slides) {
    const doc = await X(sp); const relDoc = await X(sp.replace('slides/', 'slides/_rels/') + '.rels'), rels = {};
    if (relDoc) for (const r of relDoc.getElementsByTagName('Relationship')) rels[r.getAttribute('Id')] = 'ppt/' + r.getAttribute('Target').replace(/^\.\.\//, '');
    let html = ''; const bg = doc.getElementsByTagName('p:bg')[0]; const bgc = bg ? colorOf(bg.getElementsByTagName('a:bgPr')[0]) : null;
    const place = n => { const x = q(n, 'a:xfrm')[0]; if (!x) return null; const o = q(x, 'a:off')[0], e = q(x, 'a:ext')[0]; if (!o || !e) return null; return `left:${o.getAttribute('x') / W * 100}%;top:${o.getAttribute('y') / H * 100}%;width:${e.getAttribute('cx') / W * 100}%;height:${e.getAttribute('cy') / H * 100}%;`; };
    const tree = doc.getElementsByTagName('p:spTree')[0];
    for (const n of tree.getElementsByTagName('*')) {
      if (n.tagName === 'p:pic') { const b = q(n, 'a:blip')[0], pos = place(n); const rid = b && b.getAttribute('r:embed'); if (rid && pos && rels[rid]) html += `<img style="position:absolute;${pos}object-fit:contain" src="${await mediaURL(rels[rid])}">`; }
      else if (n.tagName === 'p:sp') {
        const pos = place(n); if (!pos) continue; const spPr = q(n, 'p:spPr')[0]; const fill = colorOf(spPr); const ln = spPr && [...spPr.children].find(c => c.localName === 'ln'); const lc = colorOf(ln);
        const rr = (q(spPr, 'a:prstGeom')[0]?.getAttribute('prst') || '').includes('round') ? 'border-radius:8cqw;' : ''; let paras = '';
        for (const p of q(n, 'a:p')) {
          const al = q(p, 'a:pPr')[0]?.getAttribute('algn'); let runs = '';
          for (const r of q(p, 'a:r')) { const rp = q(r, 'a:rPr')[0], t = q(r, 'a:t')[0]?.textContent || ''; const s = rp?.getAttribute('sz'); runs += `<span style="${s ? `font-size:${s / 100 / wpt * 100}cqw;` : ''}${rp?.getAttribute('b') === '1' ? 'font-weight:700;' : ''}${rp?.getAttribute('i') === '1' ? 'font-style:italic;' : ''}${colorOf(rp) ? 'color:' + colorOf(rp) : ''}">${esc(t)}</span>`; }
          paras += `<div style="text-align:${al === 'ctr' ? 'center' : al === 'r' ? 'right' : 'left'};min-height:1em">${runs}</div>`;
        }
        html += `<div style="position:absolute;${pos}${fill ? 'background:' + fill + ';' : ''}${lc ? 'border:1px solid ' + lc + ';' : ''}${rr}display:flex;flex-direction:column;justify-content:center;overflow:hidden;color:#222;font-size:2cqw;line-height:1.2">${paras}</div>`;
      }
    }
    out.push(`<div class="slide" style="aspect-ratio:${W}/${H};background:${bgc || '#fff'}">${html}</div>`);
  }
  let i = Math.min(startIdx, out.length - 1);
  el.innerHTML = `<div class="slidebox"></div><div class="slidenav"><button class="btn sm" data-d="-1">‹ Prev</button><span></span><button class="btn sm" data-d="1">Next ›</button></div>`;
  const box = $('.slidebox', el), lab = $('.slidenav span', el);
  const show = () => { box.innerHTML = out[i]; lab.textContent = `Slide ${i + 1} / ${out.length}`; onSlide && onSlide(i, out.length); };
  el.onclick = e => { const b = e.target.closest('[data-d]'); if (b) { i = Math.max(0, Math.min(out.length - 1, i + +b.dataset.d)); show(); } };
  show(); return out.length;
}
