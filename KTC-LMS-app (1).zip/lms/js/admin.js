'use strict';
/* ===== Admin / Super-admin screens ===== */
const SEL = { users: new Set(), assigns: new Set() };
let CQ = '', UQ = '', URole = 'all', AQ = '', ACourse = 'all', AStat = 'all';
const canManage = t => isSuper() ? true : (isAdmin() && t.role === 'user');
const assignedCount = cid => S.assignments.filter(a => a.courseId === cid).length;
function purgeUserData(id) { S.assignments.filter(a => a.userId === id).forEach(a => remove('assignments', a.id)); S.progress.filter(p => p.userId === id).forEach(p => remove('progress', p.id)); }
const dsel = (id, opts, val) => `<select name="${id}">${opts.map(([v, l]) => `<option value="${v}" ${v === val ? 'selected' : ''}>${l}</option>`).join('')}</select>`;

/* ---- dashboard & more ---- */
V['a/dash'] = () => {
  const as = S.assignments.filter(a => courseOf(a.courseId) && userOf(a.userId)), st = as.map(a => aStatus(a, pctOf(a.userId, courseOf(a.courseId))));
  const top = S.courses.map(c => { const l = S.assignments.filter(a => a.courseId === c.id), d = l.filter(a => pctOf(a.userId, c) >= 100).length; return { c, n: l.length, d }; }).filter(x => x.n).sort((a, b) => b.n - a.n).slice(0, 5);
  return shell('Admin Dashboard', `<div class="stats"><div class="stat"><b>${S.users.filter(u => u.role === 'user').length}</b><span>Learners</span></div><div class="stat"><b>${S.users.filter(u => u.role !== 'user').length}</b><span>Admins</span></div><div class="stat"><b>${S.courses.length}</b><span>Courses</span></div><div class="stat"><b>${S.certs.length}</b><span>Certificates</span></div>
  <div class="stat"><b>${as.length}</b><span>Assignments</span></div><div class="stat"><b>${st.filter(x => x === 'completed').length}</b><span>Completed</span></div><div class="stat"><b>${st.filter(x => x === 'inprogress').length}</b><span>In progress</span></div><div class="stat"><b style="color:var(--bad)">${st.filter(x => x === 'overdue' || x === 'expired').length}</b><span>Overdue / closed</span></div></div>
  <div class="row wrap" style="margin-bottom:12px"><a class="btn" href="#/a/courses">＋ Course</a><a class="btn ghost" href="#/a/users">＋ User</a><a class="btn ghost" href="#/a/bulk">⬆ Bulk upload</a><a class="btn ghost" href="#/a/assign">🗓 Assign</a><a class="btn ghost" href="#/a/reports">📈 Reports</a></div>
  <div class="card"><h3 style="margin-top:0">Course completion</h3>${top.length ? top.map(x => `<div style="margin-bottom:10px"><div class="row sp sm"><span class="ell b">${esc(x.c.title)}</span><span class="muted">${x.d}/${x.n}</span></div>${barHtml(Math.round(x.d / x.n * 100))}</div>`).join('') : '<div class="muted">No assignments yet.</div>'}</div>
  <div class="card"><h3 style="margin-top:0">Recent activity</h3>${S.audit.slice(-8).reverse().map(a => `<div class="sm" style="padding:5px 0;border-bottom:1px solid var(--line)"><b>${esc(a.action)}</b> <span class="muted">${esc(a.detail)} · ${esc(a.by)} · ${new Date(a.at).toLocaleString()}</span></div>`).join('') || '<div class="muted">Nothing yet.</div>'}</div>`);
};
V['a/more'] = () => {
  const it = (h, i, t, s) => `<a class="card row" href="${h}" style="text-decoration:none;color:inherit"><div class="thumb" style="width:44px;height:44px;font-size:22px">${i}</div><div class="col"><div class="b">${t}</div><div class="sm muted">${s}</div></div>›</a>`;
  return shell('More', `${it('#/a/bulk', '⬆️', 'Bulk upload', 'Users, assignments & courses via CSV')}${it('#/a/reports', '📈', 'Reports', 'Completion, progress, CSV export')}${it('#/a/audit', '🧾', 'Audit log', 'Who changed what')}${isSuper() ? it('#/a/brand', '🎨', 'Branding & theme', 'Logo, colors, theme, certificate') + it('#/a/data', '💾', 'Backup & data', 'Export / import / reset') : ''}${it('#/profile', '👤', 'My profile', 'Details & password')}${it('#/courses', '🎓', 'My learning', 'Courses assigned to me')}
  <button class="btn block ghost" data-act="switchMode" style="margin:6px 0">👤 Switch to Learner view</button><button class="btn danger block" data-act="logout">Sign out</button>`);
};

/* ---- courses ---- */
I.cq = t => { CQ = t.value; rerender(); };
V['a/courses'] = () => {
  const L = S.courses.filter(c => (c.title + c.category).toLowerCase().includes(CQ.toLowerCase()));
  return shell('Courses', `<div class="field"><input id="cq" placeholder="Search courses…" value="${esc(CQ)}" data-in="cq"></div>${L.length ? `<div class="grid">${L.map(c => `<div class="card"><div class="row" data-act="open" data-to="#/a/course/${c.id}" style="cursor:pointer">${thumb(c)}<div class="col"><div class="b ell">${esc(c.title)}</div><div class="sm muted">${esc(c.category || 'General')} · ${c.lessons.length} lessons · ${assignedCount(c.id)} assigned</div><div style="margin-top:4px">${pill(c.status === 'published' ? 'Published' : 'Draft', c.status === 'published' ? 'ok' : 'gray')}</div></div></div>
  <div class="row wrap" style="margin-top:10px"><a class="btn sm" href="#/a/course/${c.id}">✏️ Edit</a><button class="btn sm ghost" data-act="dupCourse" data-id="${c.id}">⧉ Duplicate</button><button class="btn sm ghost" data-act="assignCourse" data-id="${c.id}">🗓 Assign</button><button class="btn sm danger" data-act="delCourse" data-id="${c.id}">🗑</button></div></div>`).join('')}</div>` : empty('No courses yet — tap ＋ to create one', '📚')}`, { fab: 'newCourse' });
};
A.newCourse = () => modal('New course', field('Title', '<input name="title" required>') + field('Category', '<input name="category" placeholder="e.g. Safety, Compliance">'), {
  submit: 'Create', onSubmit: async fd => { const c = { id: uid('c'), title: fd.get('title').trim(), category: fd.get('category').trim(), description: '', emoji: '🎓', status: 'draft', sequential: false, selfEnroll: false, lessons: [], createdAt: new Date().toISOString() }; await save('courses', c); log('Course created', c.title); closeModal(); go('#/a/course/' + c.id); }
});
A.dupCourse = async d => { const c = JSON.parse(JSON.stringify(courseOf(d.id))); c.id = uid('c'); c.title += ' (Copy)'; c.status = 'draft'; c.createdAt = new Date().toISOString(); c.lessons.forEach(l => l.id = uid('l')); await save('courses', c); log('Course duplicated', c.title); toast('Course duplicated (as draft)', 'ok'); rerender(); };
A.delCourse = async d => { const c = courseOf(d.id); if (!await confirmBox(`Delete <b>${esc(c.title)}</b>? This also removes its assignments and learner progress. Issued certificates are kept.`)) return; S.assignments.filter(a => a.courseId === c.id).forEach(a => remove('assignments', a.id)); S.progress.filter(p => p.courseId === c.id).forEach(p => remove('progress', p.id)); await remove('courses', c.id); await gcFiles(); log('Course deleted', c.title); toast('Course deleted'); if (location.hash.includes('/a/course/')) go('#/a/courses'); else rerender(); };
A.assignCourse = d => assignModal({ courseIds: [d.id] });

V['a/course'] = id => {
  const c = courseOf(id); if (!c) return shell('Course', empty('Not found'), { back: 1 });
  return shell('Edit course', `<form class="card" data-form="course" data-id="${c.id}">${field('Title', `<input name="title" value="${esc(c.title)}" required>`)}${field('Description', `<textarea name="description">${esc(c.description || '')}</textarea>`)}
  <div class="row">${'<div class="col">' + field('Category', `<input name="category" value="${esc(c.category || '')}">`) + '</div>'}<div style="width:90px">${field('Icon', `<input name="emoji" value="${esc(c.emoji || '🎓')}" maxlength="2">`)}</div></div>
  ${field('Status', dsel('status', [['draft', 'Draft (hidden from learners)'], ['published', 'Published']], c.status))}
  <div class="ck"><input type="checkbox" name="sequential" id="sq" ${c.sequential ? 'checked' : ''}><label for="sq">Sequential — lessons unlock in order</label></div>
  <div class="ck"><input type="checkbox" name="selfEnroll" id="se" ${c.selfEnroll ? 'checked' : ''}><label for="se">Allow self-enrollment from the catalog</label></div>
  ${field('Thumbnail image', `<div class="row">${c.thumbFileId ? `<img class="thumb" data-file="${c.thumbFileId}">` : ''}<input type="file" name="thumb" accept="image/*" class="col"></div>${c.thumbFileId ? '<label class="sm"><input type="checkbox" name="rmthumb"> Remove thumbnail</label>' : ''}`)}
  <div class="row wrap"><button class="btn">💾 Save course</button><button type="button" class="btn ghost" data-act="dupCourse" data-id="${c.id}">⧉ Duplicate</button><button type="button" class="btn ghost" data-act="assignCourse" data-id="${c.id}">🗓 Assign</button><button type="button" class="btn danger" data-act="delCourse" data-id="${c.id}">🗑 Delete</button></div></form>
  <div class="row sp"><h3>Lessons (${c.lessons.length})</h3><button class="btn sm" data-act="addLesson" data-cid="${c.id}">＋ Add lesson</button></div>
  <div class="card">${c.lessons.map((l, i) => `<div class="lesson"><div class="ico">${(KINDS[l.kind] || KINDS.doc)[0]}</div><div class="col"><div class="b ell">${i + 1}. ${esc(l.title)}</div><div class="sm muted">${(KINDS[l.kind] || KINDS.doc)[1]}${l.minutes ? ' · ' + l.minutes + ' min' : ''}</div></div>
  <button class="ib" data-act="mvLesson" data-cid="${c.id}" data-id="${l.id}" data-d="-1" ${i ? '' : 'disabled'}>↑</button><button class="ib" data-act="mvLesson" data-cid="${c.id}" data-id="${l.id}" data-d="1" ${i < c.lessons.length - 1 ? '' : 'disabled'}>↓</button><button class="ib" data-act="editLesson" data-cid="${c.id}" data-id="${l.id}">✏️</button><button class="ib" data-act="dupLesson" data-cid="${c.id}" data-id="${l.id}">⧉</button><button class="ib" data-act="delLesson" data-cid="${c.id}" data-id="${l.id}">🗑</button></div>`).join('') || empty('No lessons yet. Add videos, PDFs, PPTs, HTML, SCORM, YouTube, quizzes…')}</div>`, { back: 1, nav: 'a/courses' });
};
F.course = async (f, fd) => {
  const c = courseOf(f.dataset.id); Object.assign(c, { title: fd.get('title').trim(), description: fd.get('description'), category: fd.get('category').trim(), emoji: fd.get('emoji') || '🎓', status: fd.get('status'), sequential: !!fd.get('sequential'), selfEnroll: !!fd.get('selfEnroll') });
  const th = fd.get('thumb'); if (th && th.size) c.thumbFileId = await putFile(th, th.name); else if (fd.get('rmthumb')) c.thumbFileId = null;
  await save('courses', c); await gcFiles(); log('Course updated', c.title); bc.postMessage('sync'); toast('Course saved', 'ok'); rerender();
};
A.mvLesson = async d => { const c = courseOf(d.cid), i = c.lessons.findIndex(l => l.id === d.id), j = i + +d.d; [c.lessons[i], c.lessons[j]] = [c.lessons[j], c.lessons[i]]; await save('courses', c); rerender(); };
A.dupLesson = async d => { const c = courseOf(d.cid), i = c.lessons.findIndex(l => l.id === d.id), l = JSON.parse(JSON.stringify(c.lessons[i])); l.id = uid('l'); l.title += ' (Copy)'; c.lessons.splice(i + 1, 0, l); await save('courses', c); toast('Lesson duplicated', 'ok'); rerender(); };
A.delLesson = async d => { const c = courseOf(d.cid), l = c.lessons.find(x => x.id === d.id); if (!await confirmBox(`Delete lesson <b>${esc(l.title)}</b>?`)) return; c.lessons = c.lessons.filter(x => x.id !== l.id); await save('courses', c); await gcFiles(); log('Lesson deleted', l.title); rerender(); };
A.addLesson = d => lessonModal(courseOf(d.cid), null);
A.editLesson = d => { const c = courseOf(d.cid); lessonModal(c, c.lessons.find(l => l.id === d.id)); };
let QZ = null;
function drawQuiz() {
  $('#qz').innerHTML = `<div class="field"><label>Pass mark (%)</label><input type="number" min="1" max="100" value="${QZ.pass}" data-in="qzp"></div>${QZ.questions.map((q, i) => `<div class="q"><div class="row"><input placeholder="Question ${i + 1}" value="${esc(q.q)}" data-in="qzq" data-i="${i}"><button type="button" class="ib" data-act="qzDel" data-i="${i}">🗑</button></div>${q.opts.map((o, j) => `<div class="row" style="margin-top:6px"><input type="radio" name="ans${i}" ${q.ans === j ? 'checked' : ''} data-ch="qza" data-i="${i}" data-j="${j}"><input placeholder="Option ${j + 1}" value="${esc(o)}" data-in="qzo" data-i="${i}" data-j="${j}"></div>`).join('')}<div class="sm muted" style="margin-top:4px">Select the radio of the correct option</div></div>`).join('')}<button type="button" class="btn ghost sm" data-act="qzAdd">＋ Add question</button>`;
}
I.qzp = t => QZ.pass = +t.value; I.qzq = t => QZ.questions[+t.dataset.i].q = t.value; I.qzo = t => QZ.questions[+t.dataset.i].opts[+t.dataset.j] = t.value; I.qza = t => QZ.questions[+t.dataset.i].ans = +t.dataset.j;
A.qzAdd = () => { QZ.questions.push({ q: '', opts: ['', '', '', ''], ans: 0 }); drawQuiz(); }; A.qzDel = d => { QZ.questions.splice(+d.i, 1); drawQuiz(); };
function syncKind() { const k = $('#lk').value; $$('[data-for]').forEach(e => e.classList.toggle('hide', !e.dataset.for.split(' ').includes(k))); if (k === 'quiz' && !$('#qz').children.length) drawQuiz(); }
I.lk = syncKind;
I.lfile = t => { const f = t.files[0]; if (!f) return; const k = kindOf(f.name); $('#lk').value = k; syncKind(); const ti = $('.sheet [name=title]'); if (!ti.value) ti.value = f.name.replace(/\.[^.]+$/, ''); };
function lessonModal(c, l) {
  QZ = JSON.parse(JSON.stringify(l?.quiz || { pass: S.settings.passMark, questions: [{ q: '', opts: ['', '', '', ''], ans: 0 }] }));
  const opts = Object.entries(KINDS).map(([k, v]) => `<option value="${k}" ${l?.kind === k ? 'selected' : ''}>${v[0]} ${v[1]}</option>`).join('');
  const m = modal(l ? 'Edit lesson' : 'Add lesson', `${field('Title', `<input name="title" value="${esc(l?.title || '')}" required>`)}${field('Content type', `<select id="lk" name="kind" data-ch="lk">${opts}</select>`)}
  <div class="field" data-for="video audio pdf image ppt doc html zip"><label>${l?.fileId || l?.pkgId ? 'Replace file (leave empty to keep current)' : 'Upload file'}</label><input type="file" name="file" data-ch="lfile"><div class="sm muted" data-for="video">Any video format (MP4, WebM, MOV, MKV, AVI…). Playback depends on browser codec support — MP4 (H.264) is the safest.</div><div class="sm muted" data-for="zip">SCORM 1.2 / 2004 package, or a zipped HTML site (needs index.html).</div>${l?.fileId || l?.pkgId ? '<div class="sm">Current: <b>' + esc(l.fileName || (l.pkgId ? 'package' : 'file')) + '</b></div>' : ''}</div>
  <div class="field" data-for="video audio pdf image ppt doc html youtube link"><label id="ulab">URL (YouTube link, direct file link or web page)</label><input name="url" placeholder="https://…" value="${esc(l?.url || '')}"></div>
  <div class="field" data-for="text"><label>Text content</label><textarea name="text" style="min-height:160px">${esc(l?.text || '')}</textarea></div><div data-for="quiz" id="qz"></div>
  ${field('Estimated minutes (optional)', `<input name="minutes" type="number" min="0" value="${l?.minutes || ''}">`)}`, {
    onSubmit: async fd => {
      const kind = fd.get('kind'), file = fd.get('file'), url = fd.get('url').trim(), nl = l ? { ...l } : { id: uid('l') };
      Object.assign(nl, { title: fd.get('title').trim(), kind, minutes: +fd.get('minutes') || 0 });
      try {
        if (kind === 'youtube') { if (!ytId(url)) return toast('Enter a valid YouTube link', 'bad'); nl.url = url; }
        else if (kind === 'link') { if (!url) return toast('Enter the link', 'bad'); nl.url = url; }
        else if (kind === 'text') nl.text = fd.get('text');
        else if (kind === 'quiz') { const qs = QZ.questions.filter(q => q.q.trim()).map(q => ({ ...q, opts: q.opts.map(o => o.trim()) })); if (!qs.length || qs.some(q => q.opts.filter(Boolean).length < 2 || !q.opts[q.ans])) return toast('Each question needs text, ≥2 options and a valid correct answer', 'bad'); nl.quiz = { pass: QZ.pass || 70, questions: qs.map(q => { const keep = q.opts.map((o, i) => [o, i]).filter(x => x[0]); return { q: q.q.trim(), opts: keep.map(x => x[0]), ans: keep.findIndex(x => x[1] === q.ans) }; }) }; }
        else {
          if (file && file.size) {
            toast('Uploading…'); if (kind === 'zip') { const r = await importZip(file); Object.assign(nl, { pkgId: r.pkgId, launch: r.launch, launchQuery: r.launchQuery, scorm: r.scorm, fileId: null, fileName: file.name, url: '' }); }
            else { nl.fileId = await putFile(file, file.name); nl.fileName = file.name; nl.url = ''; nl.pkgId = null; }
          } else if (url && kind !== 'zip') { nl.url = url; nl.fileId = null; nl.pkgId = null; nl.fileName = ''; }
          else if (!(l && (l.fileId || l.pkgId) && l.kind === kind)) return toast('Upload a file' + (kind === 'zip' ? '' : ' or paste a URL'), 'bad');
        }
      } catch (e) { return toast(e.message || 'Upload failed', 'bad'); }
      if (!l) c.lessons.push(nl); else c.lessons[c.lessons.findIndex(x => x.id === l.id)] = nl;
      await save('courses', c); await gcFiles(); log(l ? 'Lesson updated' : 'Lesson added', `${c.title} › ${nl.title}`); closeModal(); toast('Lesson saved', 'ok'); rerender();
    }
  });
  syncKind();
}

/* ---- users ---- */
I.uq = t => { UQ = t.value; rerender(); };
A.uRole = d => { URole = d.k; rerender(); };
A.selU = d => { d.id === 'all' ? (SEL.users.size ? SEL.users.clear() : usersFiltered().forEach(u => canManage(u) && SEL.users.add(u.id))) : (SEL.users.has(d.id) ? SEL.users.delete(d.id) : SEL.users.add(d.id)); rerender(); };
const usersFiltered = () => S.users.filter(u => (URole === 'all' || u.role === URole) && (u.name + u.email + (u.empId || '') + (u.dept || '')).toLowerCase().includes(UQ.toLowerCase()));
V['a/users'] = () => {
  const L = usersFiltered(), n = SEL.users.size;
  return shell('Users', `<div class="field"><input id="uq" placeholder="Search name, email, employee ID, department…" value="${esc(UQ)}" data-in="uq"></div>
  <div class="chips">${[['all', 'All'], ['user', 'Learners'], ['admin', 'Admins'], ['superadmin', 'Super admins']].map(([k, l]) => `<button class="chip ${URole === k ? 'on' : ''}" data-act="uRole" data-k="${k}">${l}</button>`).join('')}</div>
  <div class="row sp" style="margin-bottom:8px"><button class="btn sm ghost" data-act="selU" data-id="all">${n ? 'Clear selection' : 'Select all'}</button><a class="btn sm ghost" href="#/a/bulk">⬆ Bulk upload</a></div>
  ${n ? `<div class="sticky-actions"><b class="sm">${n} selected</b><button class="btn sm" data-act="bulkAssign">🗓 Assign</button><button class="btn sm ghost" data-act="bulkStatus" data-s="active">Activate</button><button class="btn sm ghost" data-act="bulkStatus" data-s="inactive">Deactivate</button><button class="btn sm danger" data-act="bulkDelU">🗑 Delete</button></div>` : ''}
  ${L.map(u => `<div class="card"><div class="row"><input type="checkbox" ${SEL.users.has(u.id) ? 'checked' : ''} ${canManage(u) ? '' : 'disabled'} data-act="selU" data-id="${u.id}"><div class="col"><div class="b ell">${esc(u.name)} ${u.id === me().id ? pill('You') : ''}</div><div class="sm muted ell">${esc(u.email)}${u.empId ? ' · ' + esc(u.empId) : ''}${u.dept ? ' · ' + esc(u.dept) : ''}</div></div>${pill(ROLE[u.role], u.role === 'user' ? 'gray' : '')}${u.status === 'inactive' ? pill('Inactive', 'bad') : ''}</div>
  ${canManage(u) ? `<div class="row wrap" style="margin-top:8px"><button class="btn sm ghost" data-act="editUser" data-id="${u.id}">✏️ Edit</button><button class="btn sm ghost" data-act="dupUser" data-id="${u.id}">⧉ Duplicate</button><button class="btn sm ghost" data-act="assignUser" data-id="${u.id}">🗓 Assign</button><button class="btn sm ghost" data-act="resetPw" data-id="${u.id}">🔑 Reset</button>${u.id !== me().id ? `<button class="btn sm danger" data-act="delUser" data-id="${u.id}">🗑</button>` : ''}</div>` : ''}</div>`).join('') || empty('No users match')}`, { fab: 'newUser' });
};
function userModal(u, mode = 'edit') {
  const roles = isSuper() ? [['user', 'Learner'], ['admin', 'Admin'], ['superadmin', 'Super Admin']] : [['user', 'Learner']];
  modal(mode === 'edit' ? 'Edit user' : 'Add user', `<div class="row"><div class="col">${field('Employee ID', `<input name="empId" value="${esc(u?.empId || '')}">`)}</div><div class="col">${field('Role', dsel('role', roles, u?.role || 'user').replace('<select', u?.id === me().id ? '<select disabled' : '<select'))}</div></div>
  ${field('Full name', `<input name="name" value="${esc(u?.name || '')}" required>`)}${field('Email', `<input name="email" type="email" value="${esc(u?.email || '')}" required>`)}
  <div class="row"><div class="col">${field('Phone', `<input name="phone" value="${esc(u?.phone || '')}">`)}</div><div class="col">${field('Department', `<input name="dept" value="${esc(u?.dept || '')}">`)}</div></div>
  ${field('Status', dsel('status', [['active', 'Active'], ['inactive', 'Inactive']], u?.status || 'active'))}${field(mode === 'edit' ? 'New password (leave blank to keep)' : 'Password', `<input name="pw" type="text" value="${mode === 'edit' ? '' : esc(S.settings.defaultPassword)}" ${mode === 'edit' ? '' : 'required'} minlength="6">`)}
  <div class="ck"><input type="checkbox" name="mustChange" id="mc" ${mode === 'edit' ? '' : 'checked'}><label for="mc">Require password change at next login</label></div>`, {
    onSubmit: async fd => {
      const email = fd.get('email').trim().toLowerCase(), self = mode === 'edit' ? u : null;
      if (S.users.some(x => x.email.toLowerCase() === email && x.id !== self?.id)) return toast('That email already exists', 'bad');
      const emp = fd.get('empId').trim(); if (emp && S.users.some(x => (x.empId || '').toLowerCase() === emp.toLowerCase() && x.id !== self?.id)) return toast('That employee ID already exists', 'bad');
      const role = fd.get('role') || self?.role || 'user'; if (!isSuper() && role !== 'user') return toast('Only a Super Admin can create admins', 'bad');
      const n = self ? { ...self } : { id: uid('u'), createdAt: new Date().toISOString() };
      Object.assign(n, { empId: emp, name: fd.get('name').trim(), email, phone: fd.get('phone').trim(), dept: fd.get('dept').trim(), role, status: fd.get('status') });
      if (fd.get('pw')) { n.pwHash = await hashPw(fd.get('pw')); n.mustChange = !!fd.get('mustChange'); }
      await save('users', n); log(self ? 'User updated' : 'User created', `${n.name} (${ROLE[n.role]})`); bc.postMessage('sync'); closeModal(); toast('User saved', 'ok'); rerender();
    }
  });
}
A.newUser = () => userModal(null, 'new'); A.editUser = d => userModal(userOf(d.id));
A.dupUser = d => { const u = userOf(d.id); userModal({ ...u, id: null, name: u.name + ' (Copy)', email: '', empId: '' }, 'new'); };
A.assignUser = d => assignModal({ userIds: [d.id] });
A.resetPw = async d => { const u = userOf(d.id); u.pwHash = await hashPw(S.settings.defaultPassword); u.mustChange = true; await save('users', u); log('Password reset', u.name); toast(`Password reset to "${S.settings.defaultPassword}"`, 'ok'); };
A.delUser = async d => { const u = userOf(d.id); if (u.role === 'superadmin' && S.users.filter(x => x.role === 'superadmin').length < 2) return toast('Cannot delete the last Super Admin', 'bad'); if (!await confirmBox(`Delete <b>${esc(u.name)}</b>? Their assignments and progress will be removed.`)) return; purgeUserData(u.id); await remove('users', u.id); SEL.users.delete(u.id); log('User deleted', u.name); rerender(); };
A.bulkDelU = async () => { const ids = [...SEL.users].filter(id => id !== me().id && canManage(userOf(id))); if (!ids.length || !await confirmBox(`Delete ${ids.length} selected user(s)?`)) return; for (const id of ids) { const u = userOf(id); if (u.role === 'superadmin' && S.users.filter(x => x.role === 'superadmin').length < 2) continue; purgeUserData(id); await remove('users', id); } SEL.users.clear(); log('Bulk delete users', ids.length + ''); rerender(); };
A.bulkStatus = async d => { for (const id of SEL.users) { const u = userOf(id); if (u && u.id !== me().id) { u.status = d.s; await save('users', u); } } log('Bulk status', d.s); SEL.users.clear(); rerender(); toast('Updated', 'ok'); };
A.bulkAssign = () => assignModal({ userIds: [...SEL.users] });

/* ---- assignments ---- */
function assignModal(pre = {}) {
  const courses = S.courses, users = S.users.filter(u => u.status !== 'inactive'), depts = [...new Set(users.map(u => u.dept).filter(Boolean))];
  modal('Assign courses', `<div class="field"><label>Courses</label><div class="list-scroll">${courses.map(c => `<label class="ck"><input type="checkbox" name="c" value="${c.id}" ${pre.courseIds?.includes(c.id) ? 'checked' : ''}> ${esc(c.title)} ${c.status !== 'published' ? pill('Draft', 'gray') : ''}</label>`).join('') || '<div class="muted">No courses</div>'}</div></div>
  <div class="field"><label>Users</label><div class="row"><input id="af" placeholder="Filter users…" data-in="af" class="col">${depts.length ? `<select data-ch="adept" style="width:130px"><option value="">+ Department</option>${depts.map(d => `<option>${esc(d)}</option>`).join('')}</select>` : ''}</div><div class="list-scroll" style="margin-top:6px" id="ulist">${users.map(u => `<label class="ck" data-t="${esc((u.name + u.email + (u.dept || '') + (u.empId || '')).toLowerCase())}" data-dept="${esc(u.dept || '')}"><input type="checkbox" name="u" value="${u.id}" ${pre.userIds?.includes(u.id) ? 'checked' : ''}> ${esc(u.name)} <span class="muted sm">${esc(u.dept || u.email)}</span></label>`).join('')}</div></div>
  <div class="row"><div class="col">${field('Start date (access from)', `<input type="date" name="start" value="${pre.start || ''}">`)}</div><div class="col">${field('Due date', `<input type="date" name="due" value="${pre.due ?? addDays(30)}">`)}</div></div>
  <div class="ck"><input type="checkbox" name="restrict" id="rs" ${pre.restrict ? 'checked' : ''}><label for="rs">Restrict access after the due date (course locks)</label></div>`, {
    submit: 'Assign', onSubmit: async fd => {
      const cs = fd.getAll('c'), us = fd.getAll('u'); if (!cs.length || !us.length) return toast('Select at least one course and one user', 'bad');
      const start = fd.get('start'), due = fd.get('due'); if (start && due && due < start) return toast('Due date is before the start date', 'bad');
      let add = 0, upd = 0; for (const uid_ of us) for (const cid of cs) {
        let a = S.assignments.find(x => x.userId === uid_ && x.courseId === cid);
        if (a) { Object.assign(a, { startDate: start, dueDate: due, restrict: !!fd.get('restrict') }); (a.history ||= []).push({ at: new Date().toISOString(), what: `Dates updated (${start || '—'} → ${due || '—'})` }); upd++; }
        else { a = { id: uid('as'), userId: uid_, courseId: cid, startDate: start, dueDate: due, restrict: !!fd.get('restrict'), at: today(), attempt: 1, history: [{ at: new Date().toISOString(), what: 'Assigned' }] }; add++; }
        await save('assignments', a);
      }
      log('Assigned', `${add} new, ${upd} updated`); closeModal(); SEL.users.clear(); toast(`${add} assigned, ${upd} updated`, 'ok'); if (location.hash.includes('/a/assign')) rerender(); else go('#/a/assign');
    }
  });
}
I.af = t => { const q = t.value.toLowerCase(); $$('#ulist [data-t]').forEach(e => e.classList.toggle('hide', !e.dataset.t.includes(q))); };
I.adept = t => { if (t.value) $$('#ulist [data-dept]').forEach(e => { if (e.dataset.dept === t.value) e.querySelector('input').checked = true; }); t.value = ''; };
I.aq = t => { AQ = t.value; rerender(); }; I.acourse = t => { ACourse = t.value; rerender(); };
A.aStat = d => { AStat = d.k; rerender(); };
A.selA = d => { if (d.id === 'all') { const ids = assignFiltered().map(x => x.a.id); SEL.assigns.size ? SEL.assigns.clear() : ids.forEach(i => SEL.assigns.add(i)); } else SEL.assigns.has(d.id) ? SEL.assigns.delete(d.id) : SEL.assigns.add(d.id); rerender(); };
const assignFiltered = () => S.assignments.filter(a => courseOf(a.courseId) && userOf(a.userId)).map(a => { const c = courseOf(a.courseId), u = userOf(a.userId), pc = pctOf(u.id, c); return { a, c, u, pc, st: aStatus(a, pc) }; })
  .filter(x => (ACourse === 'all' || x.c.id === ACourse) && (AStat === 'all' || x.st === AStat) && (x.u.name + x.u.email + (x.u.empId || '')).toLowerCase().includes(AQ.toLowerCase()));
V['a/assign'] = () => {
  const L = assignFiltered(), n = SEL.assigns.size;
  return shell('Assignments', `<div class="field"><input id="aq" placeholder="Search learner…" value="${esc(AQ)}" data-in="aq"></div><div class="field"><select data-ch="acourse"><option value="all">All courses</option>${S.courses.map(c => `<option value="${c.id}" ${ACourse === c.id ? 'selected' : ''}>${esc(c.title)}</option>`).join('')}</select></div>
  <div class="chips">${[['all', 'All'], ['notstarted', 'Not started'], ['inprogress', 'In progress'], ['completed', 'Completed'], ['overdue', 'Overdue'], ['expired', 'Closed'], ['upcoming', 'Upcoming']].map(([k, l]) => `<button class="chip ${AStat === k ? 'on' : ''}" data-act="aStat" data-k="${k}">${l}</button>`).join('')}</div>
  <div class="row sp" style="margin-bottom:8px"><button class="btn sm ghost" data-act="selA" data-id="all">${n ? 'Clear selection' : 'Select all'}</button><span class="sm muted">${L.length} assignment(s)</span></div>
  ${n ? `<div class="sticky-actions"><b class="sm">${n} selected</b><button class="btn sm" data-act="extendA">⏳ Extend</button><button class="btn sm ghost" data-act="datesA">📅 Dates</button><button class="btn sm ghost" data-act="reassignA">🔁 Reassign</button><button class="btn sm danger" data-act="delA">🗑</button></div>` : ''}
  ${L.map(x => { const [lab, cl] = ST[x.st]; return `<div class="card"><div class="row"><input type="checkbox" ${SEL.assigns.has(x.a.id) ? 'checked' : ''} data-act="selA" data-id="${x.a.id}"><div class="col"><div class="b ell">${esc(x.u.name)}</div><div class="sm muted ell">${esc(x.c.title)}</div></div>${pill(lab, cl)}</div>
  <div class="row sm muted wrap" style="margin:8px 0 4px"><span>Start ${fmtDate(x.a.startDate)}</span><span>Due ${fmtDate(x.a.dueDate)}</span>${x.a.restrict ? pill('Restricted', 'warn') : ''}${x.a.attempt > 1 ? pill('Attempt ' + x.a.attempt) : ''}${x.a.extended ? pill('Extended ×' + x.a.extended) : ''}<b>${x.pc}%</b></div>${barHtml(x.pc)}
  <div class="row wrap" style="margin-top:8px"><button class="btn sm ghost" data-act="extendA" data-id="${x.a.id}">⏳ Extend</button><button class="btn sm ghost" data-act="datesA" data-id="${x.a.id}">📅 Dates</button><button class="btn sm ghost" data-act="reassignA" data-id="${x.a.id}">🔁 Reassign</button><button class="btn sm ghost" data-act="dupA" data-id="${x.a.id}">⧉ Duplicate</button><button class="btn sm danger" data-act="delA" data-id="${x.a.id}">🗑</button></div></div>`; }).join('') || empty('No assignments match', '🗓️')}`, { fab: 'newAssign' });
};
A.newAssign = () => assignModal();
const targets = d => d.id ? [d.id] : [...SEL.assigns];
A.dupA = d => { const a = S.assignments.find(x => x.id === d.id); assignModal({ courseIds: [a.courseId], start: a.startDate, due: a.dueDate, restrict: a.restrict }); };
A.extendA = d => { const ids = targets(d); modal(`Extend due date (${ids.length})`, field('New due date', `<input type="date" name="due" value="${addDays(7)}" required>`) + field('Reason (optional)', '<input name="why">') + '<div class="ck"><input type="checkbox" name="reopen" id="ro" checked><label for="ro">Re-open access if the course was locked</label></div>', {
  submit: 'Extend', onSubmit: async fd => { for (const id of ids) { const a = S.assignments.find(x => x.id === id); (a.history ||= []).push({ at: new Date().toISOString(), what: `Extended ${a.dueDate || '—'} → ${fd.get('due')} ${fd.get('why')}` }); a.dueDate = fd.get('due'); a.extended = (a.extended || 0) + 1; await save('assignments', a); } log('Extended', ids.length + ' assignment(s)'); closeModal(); SEL.assigns.clear(); toast('Due date extended', 'ok'); rerender(); }
}); };
A.datesA = d => { const ids = targets(d), a0 = S.assignments.find(x => x.id === ids[0]); modal(`Edit dates / restriction (${ids.length})`, `<div class="row"><div class="col">${field('Start date', `<input type="date" name="start" value="${ids.length === 1 ? a0.startDate || '' : ''}">`)}</div><div class="col">${field('Due date', `<input type="date" name="due" value="${ids.length === 1 ? a0.dueDate || '' : ''}">`)}</div></div><div class="ck"><input type="checkbox" name="restrict" id="rs2" ${ids.length === 1 && a0.restrict ? 'checked' : ''}><label for="rs2">Restrict access after due date</label></div>`, {
  onSubmit: async fd => { for (const id of ids) { const a = S.assignments.find(x => x.id === id); a.startDate = fd.get('start'); a.dueDate = fd.get('due'); a.restrict = !!fd.get('restrict'); (a.history ||= []).push({ at: new Date().toISOString(), what: 'Dates edited' }); await save('assignments', a); } closeModal(); SEL.assigns.clear(); toast('Saved', 'ok'); rerender(); }
}); };
A.reassignA = d => { const ids = targets(d); modal(`Reassign (${ids.length})`, `<p class="sm muted">Progress is reset so the learner can take the course again. Previously issued certificates are kept.</p><div class="row"><div class="col">${field('New start', `<input type="date" name="start" value="${today()}">`)}</div><div class="col">${field('New due date', `<input type="date" name="due" value="${addDays(30)}">`)}</div></div><div class="ck"><input type="checkbox" name="restrict" id="rs3"><label for="rs3">Restrict access after due date</label></div>`, {
  submit: 'Reassign', danger: true, onSubmit: async fd => { for (const id of ids) { const a = S.assignments.find(x => x.id === id); const p = getProg(a.userId, a.courseId); if (p) await remove('progress', p.id); Object.assign(a, { startDate: fd.get('start'), dueDate: fd.get('due'), restrict: !!fd.get('restrict'), attempt: (a.attempt || 1) + 1 }); (a.history ||= []).push({ at: new Date().toISOString(), what: 'Reassigned (progress reset)' }); await save('assignments', a); } log('Reassigned', ids.length + ' assignment(s)'); closeModal(); SEL.assigns.clear(); toast('Reassigned', 'ok'); rerender(); }
}); };
A.delA = async d => { const ids = targets(d); if (!await confirmBox(`Remove ${ids.length} assignment(s)? Progress is deleted.`)) return; for (const id of ids) { const a = S.assignments.find(x => x.id === id); if (!a) continue; const p = getProg(a.userId, a.courseId); if (p) await remove('progress', p.id); await remove('assignments', id); } log('Assignments removed', ids.length + ''); SEL.assigns.clear(); rerender(); };

/* ---- bulk upload ---- */
const BULK = { type: 'users', plan: null, name: '' };
const TPL = {
  users: [['action', 'employee_id', 'name', 'email', 'phone', 'department', 'role', 'status', 'password'], ['add', 'KTC2001', 'Asha Verma', 'asha@example.com', '9876500001', 'Operations', 'user', 'active', 'Welcome@123'], ['add', 'KTC2002', 'Ravi Kumar', 'ravi@example.com', '', 'Finance', 'user', 'active', ''], ['update', 'KTC1001', 'Rahul Learner', 'user@lms.app', '', 'Safety', 'user', 'active', ''], ['delete', '', '', 'old.user@example.com', '', '', '', '', '']],
  assignments: [['action', 'email', 'employee_id', 'course_title', 'start_date', 'due_date', 'restrict'], ['assign', 'user@lms.app', '', 'Welcome to the Learning Hub', '2026-11-01', '2026-11-30', 'no'], ['extend', 'user@lms.app', '', 'Welcome to the Learning Hub', '', '2026-12-15', ''], ['reassign', '', 'KTC1001', 'Welcome to the Learning Hub', '2026-12-01', '2026-12-31', 'yes'], ['delete', 'ravi@example.com', '', 'Welcome to the Learning Hub', '', '', '']],
  courses: [['course_title', 'description', 'category', 'status', 'lesson_title', 'lesson_type', 'lesson_url_or_text'], ['Fire Safety Basics', 'Annual fire safety training', 'Safety', 'published', 'Intro video', 'youtube', 'https://www.youtube.com/watch?v=aqz-KE-bpKQ'], ['Fire Safety Basics', '', '', '', 'Emergency exits', 'text', 'Know the nearest two exits on your floor.'], ['Fire Safety Basics', '', '', '', 'Company policy', 'link', 'https://example.com/policy']],
};
V['a/bulk'] = () => {
  const t = BULK.type, p = BULK.plan;
  const desc = { users: 'Create, update or delete many users at once. Use <code>action</code> = add / update / delete (blank = add or update by email). Roles: user, admin, superadmin (admins can only manage users).', assignments: 'Assign, reassign, extend or delete assignments. Match users by email or employee_id and courses by exact title. Dates as YYYY-MM-DD.', courses: 'Create courses with YouTube / link / text lessons (rows with the same course_title are grouped). Upload files such as PDF/video from the course editor afterwards.' }[t];
  return shell('Bulk upload', `<div class="chips">${[['users', 'Users'], ['assignments', 'Assignments'], ['courses', 'Courses']].map(([k, l]) => `<button class="chip ${t === k ? 'on' : ''}" data-act="bulkType" data-k="${k}">${l}</button>`).join('')}</div>
  <div class="card"><p class="sm">${desc}</p><div class="row wrap"><button class="btn" data-act="tplDl">⬇ Download CSV template</button>${t === 'users' ? '<button class="btn ghost" data-act="usersExport">⬇ Export current users</button>' : ''}</div></div>
  <div class="card"><h3 style="margin-top:0">Upload filled CSV</h3><input type="file" accept=".csv,text/csv" data-ch="bulkFile">${p ? `<div style="margin-top:12px"><div class="row wrap">${pill(p.ok.length + ' valid rows', 'ok')}${p.err.length ? pill(p.err.length + ' errors', 'bad') : ''}<span class="sm muted">${esc(BULK.name)}</span></div>
  ${p.err.length ? `<div class="list-scroll sm" style="margin:8px 0">${p.err.slice(0, 50).map(e => `<div style="padding:3px 0;color:var(--bad)">Row ${e.row}: ${esc(e.msg)}</div>`).join('')}</div>` : ''}
  ${p.ok.length ? `<button class="btn ok block" style="margin-top:8px" data-act="bulkRun">✔ Import ${p.ok.length} valid row(s)${p.err.length ? ' (skip errors)' : ''}</button>` : ''}</div>` : ''}</div>`);
};
A.bulkType = d => { BULK.type = d.k; BULK.plan = null; rerender(); };
A.tplDl = () => download(`${BULK.type}_template.csv`, toCSV(TPL[BULK.type]), 'text/csv');
A.usersExport = () => download('users_export.csv', toCSV([TPL.users[0], ...S.users.map(u => ['update', u.empId || '', u.name, u.email, u.phone || '', u.dept || '', u.role, u.status, ''])]), 'text/csv');
I.bulkFile = async t => {
  const f = t.files[0]; if (!f) return; BULK.name = f.name; const rows = csvToObjs(await f.text()), ok = [], err = [], type = BULK.type, seen = new Set();
  if (!rows.length) { BULK.plan = { ok: [], err: [{ row: 1, msg: 'The file has no data rows' }] }; return rerender(); }
  const need = { users: ['email'], assignments: ['course_title'], courses: ['course_title'] }[type];
  for (const k of need) if (!(k in rows[0])) { BULK.plan = { ok: [], err: [{ row: 1, msg: `Missing column "${k}" — download the template for the correct format` }] }; return rerender(); }
  const dOk = d => !d || /^\d{4}-\d{2}-\d{2}$/.test(d), yes = v => /^(y|yes|true|1)$/i.test(v || '');
  const findUser = r => S.users.find(u => (r.email && u.email.toLowerCase() === r.email.toLowerCase()) || (!r.email && r.employee_id && (u.empId || '').toLowerCase() === r.employee_id.toLowerCase()));
  for (const r of rows) {
    const e = msg => err.push({ row: r._row, msg });
    if (type === 'users') {
      const act = (r.action || '').toLowerCase(), ex = findUser(r), role = (r.role || '').toLowerCase().replace(/\s/g, '');
      if (!['', 'add', 'update', 'delete'].includes(act)) { e('action must be add, update or delete'); continue; }
      if (!r.email && !r.employee_id) { e('email is required'); continue; }
      if (role && !['user', 'admin', 'superadmin'].includes(role)) { e('role must be user, admin or superadmin'); continue; }
      if (r.status && !['active', 'inactive'].includes(r.status.toLowerCase())) { e('status must be active or inactive'); continue; }
      if (r.email && !/^\S+@\S+\.\S+$/.test(r.email)) { e('invalid email'); continue; }
      if (r.password && r.password.length < 6) { e('password must be at least 6 characters'); continue; }
      if (ex && !canManage(ex) || (!ex && !isSuper() && role && role !== 'user')) { e('you do not have permission for this role'); continue; }
      const key = (r.email || r.employee_id).toLowerCase(); if (seen.has(key)) { e('duplicate row in file'); continue; } seen.add(key);
      if (act === 'delete') { if (!ex) { e('user not found'); continue; } if (ex.id === me().id) { e('cannot delete yourself'); continue; } ok.push({ op: 'delete', ex }); }
      else if (act === 'update' || (act === '' && ex)) { if (!ex) { e('user not found to update'); continue; } ok.push({ op: 'update', ex, r, role }); }
      else { if (!r.name) { e('name is required'); continue; } if (!r.email) { e('email is required'); continue; } if (r.employee_id && S.users.some(u => (u.empId || '').toLowerCase() === r.employee_id.toLowerCase())) { e('employee_id already exists'); continue; } ok.push({ op: 'add', r, role: role || 'user' }); }
    } else if (type === 'assignments') {
      const act = (r.action || 'assign').toLowerCase(), u = findUser(r), c = S.courses.find(x => x.title.toLowerCase() === r.course_title.toLowerCase());
      if (!['assign', 'reassign', 'extend', 'delete'].includes(act)) { e('action must be assign, reassign, extend or delete'); continue; }
      if (!u) { e('user not found (email / employee_id)'); continue; } if (!c) { e('course title not found'); continue; }
      if (!dOk(r.start_date) || !dOk(r.due_date)) { e('dates must be YYYY-MM-DD'); continue; }
      if (r.start_date && r.due_date && r.due_date < r.start_date) { e('due date is before start date'); continue; }
      const a = S.assignments.find(x => x.userId === u.id && x.courseId === c.id);
      if (['reassign', 'extend', 'delete'].includes(act) && !a) { e('no existing assignment for this user & course'); continue; } if (act === 'extend' && !r.due_date) { e('due_date required to extend'); continue; }
      ok.push({ op: act, u, c, a, r, restrict: yes(r.restrict) });
    } else {
      if (!r.course_title) { e('course_title is required'); continue; }
      const lt = (r.lesson_type || '').toLowerCase(); if (r.lesson_title || lt) { if (!KINDS[lt] || ['quiz', 'zip'].includes(lt)) { e('lesson_type must be youtube, link, text, video, audio, pdf, image, html, ppt or doc'); continue; } if (!r.lesson_title || !r.lesson_url_or_text) { e('lesson_title and lesson_url_or_text are required'); continue; } if (lt === 'youtube' && !ytId(r.lesson_url_or_text)) { e('invalid YouTube link'); continue; } }
      if (r.status && !['draft', 'published'].includes(r.status.toLowerCase())) { e('status must be draft or published'); continue; }
      ok.push({ op: 'course', r, lt });
    }
  }
  BULK.plan = { ok, err }; rerender();
};
A.bulkRun = async () => {
  const { ok } = BULK.plan, type = BULK.type, cnt = { add: 0, update: 0, delete: 0, assign: 0, reassign: 0, extend: 0, course: 0 };
  toast('Importing…');
  for (const x of ok) {
    if (type === 'users') {
      if (x.op === 'delete') { purgeUserData(x.ex.id); await remove('users', x.ex.id); }
      else {
        const r = x.r, u = x.op === 'add' ? { id: uid('u'), createdAt: new Date().toISOString(), status: 'active' } : { ...x.ex };
        if (r.employee_id) u.empId = r.employee_id; if (r.name) u.name = r.name; if (x.op === 'add' || (r.email && !x.ex?.email)) u.email = r.email; if (r.phone) u.phone = r.phone; if (r.department) u.dept = r.department; if (x.role) u.role = x.role; else if (x.op === 'add') u.role = 'user'; if (r.status) u.status = r.status.toLowerCase();
        if (r.password || x.op === 'add') { u.pwHash = await hashPw(r.password || S.settings.defaultPassword); u.mustChange = true; } await save('users', u);
      } cnt[x.op]++;
    } else if (type === 'assignments') {
      const a = x.a ? { ...x.a } : { id: uid('as'), userId: x.u.id, courseId: x.c.id, attempt: 1, at: today(), history: [] }; a.history = a.history || [];
      if (x.op === 'delete') { const p = getProg(x.u.id, x.c.id); if (p) await remove('progress', p.id); await remove('assignments', a.id); }
      else {
        if (x.op === 'reassign') { const p = getProg(x.u.id, x.c.id); if (p) await remove('progress', p.id); a.attempt = (a.attempt || 1) + 1; }
        if (x.op === 'extend') { a.extended = (a.extended || 0) + 1; a.dueDate = x.r.due_date; } else { a.startDate = x.r.start_date; a.dueDate = x.r.due_date; a.restrict = x.restrict; }
        a.history.push({ at: new Date().toISOString(), what: 'Bulk ' + x.op }); await save('assignments', a);
      } cnt[x.op]++;
    } else {
      let c = S.courses.find(y => y.title.toLowerCase() === x.r.course_title.toLowerCase()); if (!c) { c = { id: uid('c'), title: x.r.course_title, description: x.r.description, category: x.r.category, emoji: '🎓', status: (x.r.status || 'draft').toLowerCase(), sequential: false, selfEnroll: false, lessons: [], createdAt: new Date().toISOString() }; cnt.course++; }
      else { if (x.r.description) c.description = x.r.description; if (x.r.category) c.category = x.r.category; if (x.r.status) c.status = x.r.status.toLowerCase(); }
      if (x.r.lesson_title && !c.lessons.some(l => l.title === x.r.lesson_title)) { const l = { id: uid('l'), title: x.r.lesson_title, kind: x.lt, minutes: 0 }; if (x.lt === 'text') l.text = x.r.lesson_url_or_text; else l.url = x.r.lesson_url_or_text; c.lessons.push(l); } await save('courses', c);
    }
  }
  log('Bulk import ' + type, `${ok.length} row(s)`); BULK.plan = null; bc.postMessage('sync'); toast(`Imported ${ok.length} row(s)`, 'ok'); rerender();
};

/* ---- reports / audit ---- */
function reportRows() { return S.assignments.filter(a => courseOf(a.courseId) && userOf(a.userId)).map(a => { const c = courseOf(a.courseId), u = userOf(a.userId), pc = pctOf(u.id, c), p = getProg(u.id, c.id), ce = S.certs.filter(x => x.userId === u.id && x.courseId === c.id).pop(); return { u, c, a, pc, st: aStatus(a, pc), p, ce }; }); }
V['a/reports'] = () => {
  const R = reportRows();
  const byC = S.courses.map(c => { const l = R.filter(x => x.c.id === c.id); return [c.title, l.length, l.filter(x => x.st === 'completed').length, l.filter(x => x.st === 'inprogress').length, l.filter(x => x.st === 'overdue' || x.st === 'expired').length, l.length ? Math.round(l.reduce((s, x) => s + x.pc, 0) / l.length) : 0]; });
  const byU = S.users.filter(u => u.role === 'user').map(u => { const l = R.filter(x => x.u.id === u.id); return [u.name, l.length, l.filter(x => x.st === 'completed').length, S.certs.filter(c => c.userId === u.id).length]; }).filter(x => x[1]);
  return shell('Reports', `<button class="btn block" data-act="exportReport" style="margin-bottom:12px">⬇ Export full report (CSV)</button><div class="card"><h3 style="margin-top:0">By course</h3><div class="tablewrap"><table class="t"><tr><th>Course</th><th>Assigned</th><th>Done</th><th>Active</th><th>Late</th><th>Avg %</th></tr>${byC.map(r => `<tr><td>${esc(r[0])}</td>${r.slice(1).map(v => `<td>${v}</td>`).join('')}</tr>`).join('')}</table></div></div>
  <div class="card"><h3 style="margin-top:0">By learner</h3><div class="tablewrap"><table class="t"><tr><th>Learner</th><th>Assigned</th><th>Done</th><th>Certs</th></tr>${byU.map(r => `<tr><td>${esc(r[0])}</td>${r.slice(1).map(v => `<td>${v}</td>`).join('')}</tr>`).join('') || '<tr><td colspan=4 class="muted">No data</td></tr>'}</table></div></div>`, { nav: 'a/reports' });
};
A.exportReport = () => download('lms_report_' + today() + '.csv', toCSV([['Employee ID', 'Name', 'Email', 'Department', 'Course', 'Status', 'Progress %', 'Start date', 'Due date', 'Attempt', 'Completed on', 'Certificate ID', 'Score'], ...reportRows().map(x => [x.u.empId, x.u.name, x.u.email, x.u.dept, x.c.title, ST[x.st][0], x.pc, x.a.startDate, x.a.dueDate, x.a.attempt || 1, x.p?.completedAt ? x.p.completedAt.slice(0, 10) : '', x.ce?.certNo || '', x.ce?.score || ''])]), 'text/csv');
V['a/audit'] = () => shell('Audit log', `<div class="card tablewrap"><table class="t"><tr><th>When</th><th>Who</th><th>What</th></tr>${S.audit.slice(-150).reverse().map(a => `<tr><td class="sm">${new Date(a.at).toLocaleString()}</td><td>${esc(a.by)}</td><td><b>${esc(a.action)}</b><div class="sm muted">${esc(a.detail)}</div></td></tr>`).join('')}</table></div>`, { back: 1, nav: 'a/more' });

/* ---- branding (super admin) — every change applies live across the app & other tabs ---- */
const PRESETS = ['#182B70', '#0E7C66', '#7A1FA2', '#C62828', '#E65100', '#00695C', '#1565C0', '#37474F'];
function previewCert() { const cv = $('#bcv'); if (cv) drawCertificate(cv, { name: 'Sample Learner', course: 'Sample Course Name', empId: 'EMP-001', date: fmtDate(today()), certNo: S.settings.certPrefix + '-ABC123', score: '92%', color: S.settings.certColor, org: S.settings.orgName, dept: S.settings.deptName, signatory: S.settings.signatory, signatoryTitle: S.settings.signatoryTitle, sealLabel: S.settings.sealLabel }, LOGO); }
V['a/brand'] = () => {
  const s = S.settings; AFTER = previewCert;
  return shell('Branding & theme', `<div class="card"><h3 style="margin-top:0">Logo</h3><div class="row"><div style="background:#fff;border:1px solid var(--line);border-radius:12px;padding:8px"><img class="app-logo" src="${LOGO}" style="height:56px;display:block"></div><div class="col"><input type="file" accept="image/*" data-ch="logoFile"><div class="row" style="margin-top:6px"><span class="sm muted">${s.logoFileId ? 'Custom logo' : 'Default logo'} — upload to add/replace</span>${s.logoFileId ? '<button class="btn sm danger" data-act="logoDel">Remove</button>' : ''}</div></div></div></div>
  <div class="card"><h3 style="margin-top:0">Identity</h3>${['appName:App name', 'orgName:Organization (certificate)', 'deptName:Department (certificate)'].map(x => { const [k, l] = x.split(':'); return field(l, `<input name="${k}" value="${esc(s[k])}" data-in="brand">`); }).join('')}</div>
  <div class="card"><h3 style="margin-top:0">Colors & theme</h3>${field('Primary color', `<div class="row wrap"><input type="color" name="primary" value="${s.primary}" data-in="brand" style="width:70px">${PRESETS.map(c => `<span class="sw" style="background:${c}" data-act="preset" data-c="${c}"></span>`).join('')}</div>`)}${field('Accent color', `<input type="color" name="accent" value="${s.accent}" data-in="brand" style="width:70px">`)}
  ${field('Theme', `<select name="theme" data-ch="brand">${[['light', 'Light'], ['dark', 'Dark'], ['auto', 'Match device']].map(([v, l]) => `<option value="${v}" ${s.theme === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`)}${field('Font', `<select name="font" data-ch="brand">${Object.keys(FONTS).map(v => `<option ${s.font === v ? 'selected' : ''}>${v}</option>`).join('')}</select>`)}${field('Corner roundness: ' + s.radius + 'px', `<input type="range" name="radius" min="0" max="26" value="${s.radius}" data-in="brand">`)}<button class="btn ghost sm" data-act="brandReset">↺ Reset to defaults</button></div>
  <div class="card"><h3 style="margin-top:0">Certificate</h3>${field('Certificate ID prefix', `<input name="certPrefix" value="${esc(s.certPrefix)}" data-in="brand">`)}${field('Certificate accent color', `<input type="color" name="certColor" value="${s.certColor}" data-in="brand" style="width:70px">`)}${field('Authorized signatory name', `<input name="signatory" value="${esc(s.signatory)}" data-in="brand">`)}${field('Signatory title', `<input name="signatoryTitle" value="${esc(s.signatoryTitle)}" data-in="brand">`)}${field('Seal / signature label', `<input name="sealLabel" value="${esc(s.sealLabel)}" data-in="brand">`)}<canvas id="bcv" class="cert" width="1600" height="900"></canvas><p class="sm muted">Live preview — matches the supplied KTC template. Issued certificates use the current settings when viewed/downloaded.</p></div>
  <div class="card"><h3 style="margin-top:0">Defaults</h3>${field('Default quiz pass mark (%)', `<input name="passMark" type="number" min="1" max="100" value="${s.passMark}" data-in="brand">`)}${field('Default / reset password', `<input name="defaultPassword" value="${esc(s.defaultPassword)}" data-in="brand">`)}</div>`, { back: 1, nav: 'a/more' });
};
let persistT; I.brand = t => { let v = t.value; if (t.type === 'range' || t.type === 'number') v = +v; S.settings[t.name] = v; applyTheme(); previewCert(); clearTimeout(persistT); persistT = setTimeout(() => saveSettings({}), 250); if (t.type === 'select-one' || t.type === 'range') { if (t.name === 'radius') t.previousElementSibling.textContent = 'Corner roundness: ' + v + 'px'; } if (t.tagName === 'SELECT') { saveSettings({}); } };
A.preset = d => { S.settings.primary = d.c; saveSettings({}); applyTheme(); $('[name=primary]').value = d.c; previewCert(); };
A.brandReset = async () => { if (!await confirmBox('Reset colors, theme and fonts to defaults?', 'Reset')) return; const s = S.settings; await saveSettings({ primary: DEFAULTS.primary, accent: DEFAULTS.accent, theme: 'light', font: 'system', radius: 14, certColor: DEFAULTS.certColor }); applyTheme(); rerender(); };
I.logoFile = async t => { const f = t.files[0]; if (!f) return; if (!f.type.startsWith('image/')) return toast('Choose an image file', 'bad'); const id = await putFile(f, f.name); await saveSettings({ logoFileId: id }); await gcFiles(); await refreshLogo(); applyTheme(); log('Logo changed'); toast('Logo updated everywhere', 'ok'); rerender(); };
A.logoDel = async () => { await saveSettings({ logoFileId: null }); await gcFiles(); await refreshLogo(); applyTheme(); log('Logo removed'); toast('Logo removed — default restored'); rerender(); };

/* ---- backup ---- */
V['a/data'] = () => shell('Backup & data', `<div class="card"><h3 style="margin-top:0">Backup</h3><p class="sm muted">Exports users, courses (metadata), assignments, progress, certificates, audit log and branding as JSON. Uploaded files (videos, PDFs, packages) stay in this browser and are not included.</p><button class="btn" data-act="backup">⬇ Export backup</button></div>
  <div class="card"><h3 style="margin-top:0">Restore</h3><input type="file" accept=".json" data-ch="restore"></div><div class="card"><h3 style="margin-top:0;color:var(--bad)">Danger zone</h3><button class="btn danger" data-act="wipe">Erase all data & reset demo</button></div>`, { back: 1, nav: 'a/more' });
A.backup = () => download('lms_backup_' + today() + '.json', JSON.stringify({ v: 1, at: new Date().toISOString(), users: S.users, courses: S.courses, assignments: S.assignments, progress: S.progress, certs: S.certs, audit: S.audit, settings: S.settings }), 'application/json');
I.restore = async t => {
  const f = t.files[0]; if (!f) return; let d; try { d = JSON.parse(await f.text()); if (!Array.isArray(d.users) || !d.users.some(u => u.role === 'superadmin')) throw 0; } catch (e) { return toast('Not a valid backup file', 'bad'); }
  if (!await confirmBox('Replace ALL current data with this backup?', 'Restore')) return;
  for (const s of ['users', 'courses', 'assignments', 'progress', 'certs', 'audit']) { await DB.clear(s); for (const o of d[s] || []) await DB.put(s, o); } await DB.put('settings', d.settings || DEFAULTS); await syncAll(); bc.postMessage('sync'); toast('Backup restored', 'ok'); rerender();
};
A.wipe = async () => { if (!await confirmBox('This permanently erases every user, course, file and certificate in this browser.', 'Erase everything')) return; for (const s of STORES) await DB.clear(s); await loadAll(); await seed(); SESSION = null; localStorage.removeItem('lms.session'); await refreshLogo(); applyTheme(); bc.postMessage('sync'); go('#/'); render(); };
