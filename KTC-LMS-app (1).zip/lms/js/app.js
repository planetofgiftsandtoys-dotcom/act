'use strict';
/* ===== App shell, auth, learner experience ===== */
const A = {}, F = {}, I = {}, V = {};
let AFTER = null, CLEANUP = null, SESSION = localStorage.getItem('lms.session');
const me = () => S.users.find(u => u.id === SESSION && u.status !== 'inactive') || null;
const isAdmin = () => { const u = me(); return !!u && (u.role === 'admin' || u.role === 'superadmin'); };
const isSuper = () => { const u = me(); return !!u && u.role === 'superadmin'; };
const mode = () => isAdmin() && localStorage.getItem('lms.mode') !== 'learner' ? 'admin' : 'learner';
const ROLE = { superadmin: 'Super Admin', admin: 'Admin', user: 'Learner' };
const KINDS = { video: ['🎬', 'Video'], youtube: ['▶️', 'YouTube'], audio: ['🎧', 'Audio'], pdf: ['📕', 'PDF'], image: ['🖼️', 'Image'], ppt: ['📊', 'PowerPoint'], doc: ['📄', 'Document'], html: ['🌐', 'HTML'], zip: ['📦', 'SCORM / Web package'], link: ['🔗', 'Web link'], text: ['📝', 'Text'], quiz: ['❓', 'Quiz'] };
const FONTS = { system: 'system-ui,-apple-system,"Segoe UI",Roboto,sans-serif', serif: 'Georgia,"Times New Roman",serif', rounded: '"Trebuchet MS","Segoe UI",sans-serif', mono: 'ui-monospace,Menlo,Consolas,monospace' };
let LOGO = 'assets/logo.png';

/* ---- theme (applies instantly everywhere) ---- */
async function refreshLogo() { const id = S.settings.logoFileId; LOGO = (id && await fileURL(id)) || 'assets/logo.png'; }
function applyTheme() {
  const s = S.settings, r = document.documentElement;
  r.style.setProperty('--primary', s.primary); r.style.setProperty('--accent', s.accent); r.style.setProperty('--radius', s.radius + 'px'); r.style.setProperty('--font', FONTS[s.font] || FONTS.system);
  const hex = s.primary.replace('#', ''), [R, G, B] = [0, 2, 4].map(i => parseInt(hex.substr(i, 2), 16));
  r.style.setProperty('--on-primary', (0.299 * R + 0.587 * G + 0.114 * B) > 160 ? '#111' : '#fff');
  const dark = s.theme === 'dark' || (s.theme === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches); r.dataset.theme = dark ? 'dark' : 'light';
  document.title = s.appName; $('meta[name=theme-color]').content = s.primary; $('#favicon').href = LOGO;
  $$('.app-logo').forEach(i => i.src = LOGO); $$('.app-name').forEach(i => i.textContent = s.appName);
}
async function syncAll() { await loadAll(); await refreshLogo(); applyTheme(); if (!$('#modal-root').children.length && !$('#content')) render(); else applyTheme(); }
bc.onmessage = () => syncAll();
matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', applyTheme);

/* ---- ui helpers ---- */
const toast = (m, t = '') => { const d = document.createElement('div'); d.className = 'toast ' + t; d.textContent = m; $('#toast-root').appendChild(d); setTimeout(() => d.remove(), 3200); };
function modal(title, body, { onSubmit, wide, submit = 'Save', cancel = 'Cancel', danger } = {}) {
  closeModal(); const d = document.createElement('div'); d.className = 'back';
  d.innerHTML = `<form class="sheet" data-form="modal"><h3>${title}</h3>${body}<div class="row" style="margin-top:14px;justify-content:flex-end">${cancel ? `<button type="button" class="btn ghost" data-act="closeModal">${cancel}</button>` : ''}${onSubmit || submit ? `<button class="btn ${danger ? 'danger' : ''}">${submit}</button>` : ''}</div></form>`;
  d.addEventListener('mousedown', e => { if (e.target === d) closeModal(); }); $('#modal-root').appendChild(d); F.modal = (f, fd) => onSubmit ? onSubmit(fd, f) : closeModal();
  return d;
}
const closeModal = () => { $('#modal-root').innerHTML = ''; };
A.closeModal = closeModal;
const confirmBox = (msg, label = 'Delete') => new Promise(res => { modal('Please confirm', `<p>${msg}</p>`, { submit: label, danger: true, onSubmit: () => { closeModal(); res(true); } }); const c = $('#modal-root [data-act=closeModal]'); c.addEventListener('click', () => res(false)); });
const pill = (t, c = '') => `<span class="pill ${c}">${esc(t)}</span>`;
const barHtml = p => `<div class="bar"><i style="width:${p}%"></i></div>`;
const empty = (m, i = '📭') => `<div class="empty"><div style="font-size:38px">${i}</div>${m}</div>`;
const field = (label, input) => `<div class="field"><label>${label}</label>${input}</div>`;
const go = h => { location.hash = h; };
const userOf = id => S.users.find(u => u.id === id);
const courseOf = id => S.courses.find(c => c.id === id);
const thumb = c => c.thumbFileId ? `<img class="thumb" data-file="${c.thumbFileId}" alt="">` : `<div class="thumb">${c.emoji || '🎓'}</div>`;
async function hydrate() { for (const el of $$('[data-file]')) { const u = await fileURL(el.dataset.file); if (u) el.src = u; } }

/* ---- progress & assignments ---- */
const getProg = (u, c) => S.progress.find(p => p.id === u + ':' + c);
const started = (u, c) => { const p = getProg(u, c.id); return !!p && Object.values(p.lessons).some(x => x.done || x.pos > 0 || x.scorm || x.attempts); };
const pctOf = (u, c) => { const n = (c.lessons || []).length; if (!n) return 0; const p = getProg(u, c.id); return p ? Math.floor(c.lessons.filter(l => p.lessons[l.id]?.done).length / n * 100) : 0; };
function aStatus(a, pc) {
  const t = today(); if (pc >= 100) return 'completed'; if (a.startDate && t < a.startDate) return 'upcoming';
  if (a.dueDate && t > a.dueDate) return a.restrict ? 'expired' : 'overdue'; return pc > 0 ? 'inprogress' : 'notstarted';
}
const ST = { completed: ['Completed', 'ok'], upcoming: ['Upcoming', 'gray'], expired: ['Closed', 'bad'], overdue: ['Overdue', 'bad'], inprogress: ['In progress', 'warn'], notstarted: ['Not started', ''] };
const myAssignments = uid => S.assignments.filter(a => a.userId === uid && courseOf(a.courseId)).map(a => { const c = courseOf(a.courseId), pc = pctOf(uid, c); return { a, c, pc, st: aStatus(a, pc) }; });
function access(u, c) {
  const a = S.assignments.find(x => x.userId === u.id && x.courseId === c.id);
  if (!a) return isAdmin() ? { ok: true, preview: true } : { ok: false, why: 'This course is not assigned to you.' };
  const pc = pctOf(u.id, c), st = aStatus(a, pc);
  if (st === 'upcoming') return { ok: false, why: `This course opens on ${fmtDate(a.startDate)}.`, a };
  if (st === 'expired') return { ok: false, why: `Access closed on ${fmtDate(a.dueDate)}. Ask your admin for an extension.`, a };
  if (c.status !== 'published' && !isAdmin()) return { ok: false, why: 'This course is not published yet.', a };
  return { ok: true, a };
}
const unlocked = (u, c, idx) => { if (!c.sequential) return true; const p = getProg(u.id, c.id); return c.lessons.slice(0, idx).every(l => p?.lessons[l.id]?.done); };
function resumeLesson(u, c) {
  const p = getProg(u.id, c.id); if (!c.lessons.length) return null;
  if (p?.last && !p.lessons[p.last]?.done && c.lessons.find(l => l.id === p.last)) return p.last;
  return (c.lessons.find(l => !p?.lessons[l.id]?.done) || c.lessons[0]).id;
}
function newCertNo() { let n; do { n = S.settings.certPrefix + '-' + Math.random().toString(36).slice(2, 8).toUpperCase(); } while (S.certs.find(c => c.certNo === n)); return n; }
function issueCert(u, c, pr) {
  if (S.certs.find(x => x.userId === u.id && x.courseId === c.id && x.attempt === pr.attempt)) return null;
  const sc = c.lessons.filter(l => l.kind === 'quiz').map(l => pr.lessons[l.id]?.score).filter(x => x != null);
  const cert = { id: uid('c'), certNo: newCertNo(), userId: u.id, courseId: c.id, attempt: pr.attempt, name: u.name, empId: u.empId || '', course: c.title, date: today(), score: sc.length ? Math.round(sc.reduce((a, b) => a + b, 0) / sc.length) + '%' : 'COMPLETED', issuedAt: new Date().toISOString() };
  save('certs', cert); log('Certificate issued', `${u.name} · ${c.title} · ${cert.certNo}`); return cert;
}
function completeLesson(c, l, extra = {}) {
  const u = me(); let pr = getProg(u.id, c.id); if (!pr) return; const lp = pr.lessons[l.id] || (pr.lessons[l.id] = {});
  const was = lp.done; Object.assign(lp, extra, { done: true, at: new Date().toISOString() }); pr.last = l.id; let cert = null;
  if (pctOf(u.id, c) >= 100 && !pr.completedAt) { pr.completedAt = new Date().toISOString(); cert = issueCert(u, c, pr); }
  save('progress', pr); if (!was) toast('✅ Lesson completed', 'ok'); if (cert) setTimeout(() => toast('🎓 Course complete — certificate generated!', 'ok'), 600);
  const bar = $('#pbar'); if (bar) bar.innerHTML = playerBar(c, l);
}

/* ---- render ---- */
const NAV_L = [['home', '🏠', 'Home'], ['courses', '📚', 'My Courses'], ['catalog', '🔎', 'Catalog'], ['certs', '🎓', 'Certificates'], ['profile', '👤', 'Profile']];
const NAV_A = [['home', '📊', 'Dashboard'], ['a/courses', '📚', 'Courses'], ['a/users', '👥', 'Users'], ['a/assign', '🗓️', 'Assign'], ['a/reports', '📈', 'Reports'], ['a/more', '☰', 'More']];
function notifications() {
  const u = me(), out = []; for (const x of myAssignments(u.id)) {
    if (x.st === 'overdue') out.push(['⚠️', `${x.c.title} is overdue (due ${fmtDate(x.a.dueDate)})`]);
    else if (x.st !== 'completed' && x.a.dueDate && x.a.dueDate <= addDays(3) && x.a.dueDate >= today()) out.push(['⏰', `${x.c.title} is due ${fmtDate(x.a.dueDate)}`]);
    else if (x.st === 'notstarted' && x.a.at > addDays(-3)) out.push(['📌', `New course assigned: ${x.c.title}`]);
  } return out;
}
function shell(title, body, o = {}) {
  const u = me(), m = mode(), nav = m === 'admin' ? NAV_A : NAV_L, cur = o.nav || location.hash.replace(/^#\/?/, '').split('/').slice(0, location.hash.includes('#/a/') ? 2 : 1).join('/') || 'home';
  const n = notifications().length;
  return `<header class="top">${o.back ? `<button class="hbtn" data-act="back">‹ Back</button>` : `<span class="logo"><img class="app-logo" src="${LOGO}" alt=""></span>`}<h1>${esc(title)}</h1>
  ${isAdmin() ? `<button class="hbtn" data-act="switchMode" title="Switch view">${m === 'admin' ? '👤 Learner view' : '🛠 Admin view'}</button>` : ''}
  <button class="hbtn" data-act="bell">🔔${n ? '<span class="dot"></span>' : ''}</button></header>
  <main>${body}</main>${o.fab ? `<button class="fab" data-act="${o.fab}" aria-label="Add">＋</button>` : ''}
  <nav class="bottom">${nav.map(([p, i, l]) => `<a href="#/${p}" class="${cur === p ? 'on' : ''}"><i>${i}</i>${l}</a>`).join('')}</nav>`;
}
function render() {
  if (CLEANUP) { try { CLEANUP(); } catch (e) { } CLEANUP = null; }
  const root = $('#app'), ae = document.activeElement, aid = ae && ae.id, sel = ae && ae.selectionStart;
  const hash = location.hash.replace(/^#\/?/, ''); const parts = hash.split('/');
  if (parts[0] === 'verify') { root.innerHTML = V.verify(); applyTheme(); return; }
  const u = me(); if (!u) { root.innerHTML = loginView(); applyTheme(); return; }
  if (u.mustChange && !$('#modal-root').children.length) setTimeout(forcePw, 50);
  let key = parts[0] || 'home', args = parts.slice(1); if (key === 'a') { key = 'a/' + (parts[1] || 'more'); args = parts.slice(2); }
  if (key.startsWith('a/') && !isAdmin()) key = 'home';
  if (key === 'a/brand' || key === 'a/data') if (!isSuper()) key = 'a/more';
  if (key === 'home' && mode() === 'admin') key = 'a/dash';
  const view = V[key] || V.home; let html;
  try { html = view(...args); } catch (e) { console.error(e); html = shell('Error', `<div class="card">Something went wrong: ${esc(e.message)}</div>`); }
  root.innerHTML = html; applyTheme(); hydrate(); window.scrollTo(0, 0);
  if (aid && $('#' + aid)) { const e = $('#' + aid); e.focus(); try { e.setSelectionRange(sel, sel); } catch (x) { } }
  if (AFTER) { const f = AFTER; AFTER = null; f(); }
}
const rerender = () => { const y = scrollY; render(); scrollTo(0, y); };
window.addEventListener('hashchange', () => { closeModal(); render(); });
document.addEventListener('click', e => { const t = e.target.closest('[data-act]'); if (t && A[t.dataset.act]) { e.preventDefault(); A[t.dataset.act](t.dataset, t, e); } });
document.addEventListener('submit', e => { const f = e.target.closest('form[data-form]'); if (f) { e.preventDefault(); const h = F[f.dataset.form]; h && h(f, new FormData(f)); } });
document.addEventListener('input', e => { const t = e.target; if (t.dataset.in && I[t.dataset.in]) I[t.dataset.in](t, e); });
document.addEventListener('change', e => { const t = e.target; if (t.dataset.ch && I[t.dataset.ch]) I[t.dataset.ch](t, e); });
A.back = () => history.length > 1 ? history.back() : go('#/home');
A.switchMode = () => { localStorage.setItem('lms.mode', mode() === 'admin' ? 'learner' : 'admin'); go('#/home'); render(); toast(mode() === 'admin' ? 'Switched to Admin view' : 'Switched to Learner view'); };
A.bell = () => { const n = notifications(); modal('Notifications', n.length ? n.map(x => `<div class="ck"><span>${x[0]}</span><span>${esc(x[1])}</span></div>`).join('') : empty('You are all caught up', '🎉'), { submit: '', cancel: 'Close' }); };

/* ---- login / session ---- */
function loginView() {
  const s = S.settings;
  return `<div style="flex:1;display:flex;background:linear-gradient(160deg,var(--primary),var(--primary-d))"><div class="login"><div class="brand"><div class="logo"><img class="app-logo" src="${LOGO}" alt=""></div><h2 class="app-name" style="color:var(--on-primary);margin-top:12px">${esc(s.appName)}</h2></div>
  <form class="card" data-form="login">${field('Email or Employee ID', '<input name="id" autocomplete="username" required autofocus>')}${field('Password', '<input name="pw" type="password" autocomplete="current-password" required>')}
  <button class="btn block">Sign in</button><p class="sm muted" style="text-align:center;margin:12px 0 0">Forgot password? Ask your admin to reset it.</p>
  <p class="sm" style="text-align:center;margin:6px 0 0"><a href="#/verify">Verify a certificate</a></p></form></div></div>`;
}
F.login = async (f, fd) => {
  const id = fd.get('id').trim().toLowerCase(), h = await hashPw(fd.get('pw'));
  const u = S.users.find(x => x.email.toLowerCase() === id || (x.empId && x.empId.toLowerCase() === id));
  if (!u || u.pwHash !== h) return toast('Wrong ID or password', 'bad');
  if (u.status === 'inactive') return toast('This account is deactivated', 'bad');
  myTab = 'all'; SESSION = u.id; localStorage.setItem('lms.session', u.id); u.lastLogin = new Date().toISOString(); save('users', u); log('Login'); go('#/home'); render();
};
A.logout = () => { log('Logout'); SESSION = null; localStorage.removeItem('lms.session'); go('#/'); render(); };
function forcePw() {
  modal('Set a new password', `<p class="muted sm">You must change your temporary password before continuing.</p>${field('New password (min 6 chars)', '<input name="p1" type="password" minlength="6" required>')}${field('Confirm password', '<input name="p2" type="password" required>')}`, {
    cancel: '', submit: 'Update password', onSubmit: async fd => { if (fd.get('p1') !== fd.get('p2')) return toast('Passwords do not match', 'bad'); const u = me(); u.pwHash = await hashPw(fd.get('p1')); u.mustChange = false; await save('users', u); closeModal(); toast('Password updated', 'ok'); }
  });
}

/* ---- learner views ---- */
function courseCard(x, link = true) {
  const { a, c, pc, st } = x, [lab, cl] = ST[st];
  return `<div class="card click" data-act="open" data-to="#/course/${c.id}"><div class="row">${thumb(c)}<div class="col"><div class="b ell">${esc(c.title)}</div><div class="sm muted ell">${esc(c.category || 'General')} · ${c.lessons.length} lessons</div><div class="row sm" style="margin-top:4px">${pill(lab, cl)}${a.dueDate ? `<span class="muted">Due ${fmtDate(a.dueDate)}</span>` : ''}</div></div></div><div class="row" style="margin-top:10px"><div class="col">${barHtml(pc)}</div><b class="sm">${pc}%</b></div></div>`;
}
A.open = d => go(d.to);
V.home = () => {
  const u = me(), list = myAssignments(u.id), cert = S.certs.filter(c => c.userId === u.id).length;
  const live = list.filter(x => x.st === 'inprogress' || x.st === 'notstarted' || x.st === 'overdue').sort((a, b) => (getProg(u.id, b.c.id)?.lessons ? Object.values(getProg(u.id, b.c.id).lessons).map(l => l.at || '').sort().pop() || '' : '').localeCompare(getProg(u.id, a.c.id)?.lessons ? Object.values(getProg(u.id, a.c.id).lessons).map(l => l.at || '').sort().pop() || '' : ''));
  const cont = live.find(x => started(u.id, x.c)) || live[0];
  return shell(S.settings.appName, `<h2>Hello, ${esc(u.name.split(' ')[0])} 👋</h2>
  ${cont ? `<div class="hero"><div class="sm" style="opacity:.8">${started(u.id, cont.c) ? 'Continue where you left off' : 'Start learning'}</div><div class="b" style="font-size:18px;margin:4px 0 10px">${esc(cont.c.title)}</div><div class="bar" style="background:rgba(255,255,255,.25)"><i style="width:${cont.pc}%;background:var(--accent)"></i></div><div class="row sp" style="margin-top:12px"><span class="sm">${cont.pc}% complete</span><a class="btn sm" href="#/learn/${cont.c.id}/${resumeLesson(u, cont.c)}">${started(u.id, cont.c) ? 'Resume ▶' : 'Start ▶'}</a></div></div>` : ''}
  <div class="stats"><div class="stat"><b>${list.length}</b><span>Assigned</span></div><div class="stat"><b>${list.filter(x => x.st === 'inprogress').length}</b><span>In progress</span></div><div class="stat"><b>${list.filter(x => x.st === 'completed').length}</b><span>Completed</span></div><div class="stat"><b>${cert}</b><span>Certificates</span></div></div>
  <h3>My learning</h3>${list.length ? `<div class="grid">${list.filter(x => x.st !== 'completed').map(courseCard).join('') || empty('Nothing pending — great work!', '🎉')}</div>` : empty('No courses assigned yet. Browse the catalog or ask your admin.')}`);
};
let myTab = 'all';
V.courses = () => {
  const u = me(), all = myAssignments(u.id), L = all.filter(x => myTab === 'all' || (myTab === 'inprogress' && ['inprogress', 'notstarted'].includes(x.st)) || x.st === myTab);
  const tabs = [['all', 'All'], ['inprogress', 'Active'], ['completed', 'Completed'], ['overdue', 'Overdue'], ['upcoming', 'Upcoming']];
  return shell('My Courses', `<div class="chips">${tabs.map(([k, l]) => `<button class="chip ${myTab === k ? 'on' : ''}" data-act="myTab" data-k="${k}">${l}</button>`).join('')}</div>${L.length ? `<div class="grid">${L.map(courseCard).join('')}</div>` : empty('No courses here')}`);
};
A.myTab = d => { myTab = d.k; rerender(); };
let catQ = '';
I.catQ = t => { catQ = t.value; rerender(); };
V.catalog = () => {
  const u = me(), list = S.courses.filter(c => c.status === 'published' && (c.title + c.category + c.description).toLowerCase().includes(catQ.toLowerCase()));
  return shell('Course Catalog', `<div class="field"><input id="catq" placeholder="Search courses…" value="${esc(catQ)}" data-in="catQ"></div>${list.length ? `<div class="grid">${list.map(c => {
    const a = S.assignments.find(x => x.userId === u.id && x.courseId === c.id);
    return `<div class="card"><div class="row">${thumb(c)}<div class="col"><div class="b">${esc(c.title)}</div><div class="sm muted">${esc(c.category || 'General')} · ${c.lessons.length} lessons</div></div></div><p class="sm muted">${esc((c.description || '').slice(0, 120))}</p>${a ? `<a class="btn sm ghost" href="#/course/${c.id}">Open</a>` : c.selfEnroll ? `<button class="btn sm" data-act="enroll" data-id="${c.id}">Enroll</button>` : pill('By assignment', 'gray')}</div>`;
  }).join('')}</div>` : empty('No courses found')}`);
};
A.enroll = d => { const u = me(); save('assignments', { id: uid('as'), userId: u.id, courseId: d.id, startDate: '', dueDate: '', restrict: false, at: today(), history: [{ at: new Date().toISOString(), what: 'Self-enrolled' }] }); log('Self-enrolled', courseOf(d.id).title); toast('Enrolled!', 'ok'); go('#/course/' + d.id); render(); };
V.course = id => {
  const u = me(), c = courseOf(id); if (!c) return shell('Course', empty('Course not found'), { back: 1 });
  const ac = access(u, c), p = getProg(u.id, c.id), pc = pctOf(u.id, c), a = ac.a, cert = S.certs.filter(x => x.userId === u.id && x.courseId === c.id).pop();
  const head = `<div class="card"><div class="row">${thumb(c)}<div class="col"><h2 style="margin:0">${esc(c.title)}</h2><div class="sm muted">${esc(c.category || 'General')}</div></div></div><p>${esc(c.description || '')}</p>
  ${a ? `<div class="row wrap sm muted"><span>📅 Start: ${fmtDate(a.startDate)}</span><span>⏳ Due: ${fmtDate(a.dueDate)}</span>${a.restrict ? pill('Access ends on due date', 'warn') : ''}</div>` : ''}<div class="row" style="margin:12px 0">${'<div class="col">' + barHtml(pc) + '</div>'}<b>${pc}%</b></div>
  ${ac.ok ? (c.lessons.length ? `<a class="btn block" href="#/learn/${c.id}/${resumeLesson(u, c)}">${pc >= 100 ? 'Review course' : started(u.id, c) ? '▶ Continue where you left' : '▶ Start course'}</a>` : '<div class="muted">No lessons yet.</div>') : `<div class="pill bad" style="display:block;padding:10px">${esc(ac.why)}</div>${!a && c.selfEnroll ? `<button class="btn block" style="margin-top:10px" data-act="enroll" data-id="${c.id}">Enroll now</button>` : ''}`}
  ${cert ? `<a class="btn block ok" style="margin-top:8px" href="#/cert/${cert.id}">🎓 View / Download certificate</a>` : pc < 100 && ac.ok ? '<p class="sm muted" style="margin:10px 0 0">🎓 Certificate is generated automatically after you complete 100% of the course.</p>' : ''}</div>`;
  const ls = c.lessons.map((l, i) => { const d = p?.lessons[l.id]?.done, lock = ac.ok && !unlocked(u, c, i), k = KINDS[l.kind] || KINDS.doc; return `<div class="lesson ${d ? 'done' : ''} ${lock ? 'lock' : ''}" ${ac.ok && !lock ? `data-act="open" data-to="#/learn/${c.id}/${l.id}" style="cursor:pointer"` : ''}><div class="ico">${d ? '✅' : lock ? '🔒' : k[0]}</div><div class="col"><div class="b ell">${i + 1}. ${esc(l.title)}</div><div class="sm muted">${k[1]}${l.minutes ? ' · ' + l.minutes + ' min' : ''}</div></div>${p?.last === l.id && !d ? pill('Resume', 'warn') : ''}</div>`; }).join('');
  return shell('Course', head + `<div class="card"><h3 style="margin-top:0">Content</h3>${ls || empty('No lessons yet')}</div>`, { back: 1, nav: 'courses' });
};

/* ---- player ---- */
function playerBar(c, l) {
  const u = me(), p = getProg(u.id, c.id), i = c.lessons.findIndex(x => x.id === l.id), pc = pctOf(u.id, c), d = p?.lessons[l.id]?.done, prev = c.lessons[i - 1], next = c.lessons[i + 1], cert = S.certs.filter(x => x.userId === u.id && x.courseId === c.id).pop();
  return `<div class="row" style="margin-bottom:8px"><div class="col">${barHtml(pc)}</div><b class="sm">${pc}%</b></div>
  ${cert ? `<a class="btn block ok" style="margin-bottom:8px" href="#/cert/${cert.id}">🎓 Certificate ready — view & download</a>` : ''}
  <div class="row"><a class="btn ghost ${prev ? '' : 'hide'}" href="#/learn/${c.id}/${prev?.id}">‹ Prev</a><span class="col" style="text-align:center">${d ? pill('Completed ✓', 'ok') : ''}</span>${next ? `<a class="btn ${d ? '' : 'ghost'}" href="#/learn/${c.id}/${next.id}">Next ›</a>` : `<a class="btn ghost" href="#/course/${c.id}">Finish</a>`}</div>`;
}
V.learn = (cid, lid) => {
  const u = me(), c = courseOf(cid), idx = c ? c.lessons.findIndex(l => l.id === lid) : -1;
  if (!c || idx < 0) return shell('Lesson', empty('Lesson not found'), { back: 1 });
  const ac = access(u, c); if (!ac.ok) { toast(ac.why, 'bad'); setTimeout(() => go('#/course/' + cid), 50); return shell('Locked', empty(esc(ac.why), '🔒'), { back: 1 }); }
  if (!unlocked(u, c, idx)) { toast('Complete the previous lessons first', 'bad'); setTimeout(() => go('#/course/' + cid), 50); return shell('Locked', empty('Complete previous lessons first', '🔒'), { back: 1 }); }
  const l = c.lessons[idx]; let pr = getProg(u.id, c.id);
  if (!pr) pr = { id: u.id + ':' + c.id, userId: u.id, courseId: c.id, lessons: {}, last: null, startedAt: new Date().toISOString(), completedAt: null, attempt: ac.a?.attempt || 1 };
  pr.lessons[l.id] = pr.lessons[l.id] || {}; pr.last = l.id; save('progress', pr);
  AFTER = () => mountLesson(c, l, pr);
  return shell(c.title, `<div class="row sp" style="margin-bottom:8px"><div class="col"><div class="sm muted">Lesson ${idx + 1} of ${c.lessons.length} · ${(KINDS[l.kind] || KINDS.doc)[1]}</div><h2 style="margin:0">${esc(l.title)}</h2></div><a class="ib" style="display:flex;align-items:center;justify-content:center;text-decoration:none" href="#/course/${c.id}">☰</a></div>
  <div id="content" class="player"><div class="empty">Loading…</div></div><div class="card" id="pbar">${playerBar(c, l)}</div>`, { back: 1, nav: 'courses' });
};
const manualBtn = (c, l) => { const d = getProg(me().id, c.id)?.lessons[l.id]?.done; return `<div class="pad"><button class="btn block ${d ? 'ghost' : 'ok'}" data-act="manual" ${d ? 'disabled' : ''}>${d ? 'Completed ✓' : '✔ Mark as complete'}</button></div>`; };
function loadYT() { return new Promise((res, rej) => { if (window.YT && YT.Player) return res(); const s = document.createElement('script'); s.src = 'https://www.youtube.com/iframe_api'; window.onYouTubeIframeAPIReady = res; s.onerror = rej; document.head.appendChild(s); setTimeout(() => rej(new Error('timeout')), 8000); }); }
async function mountLesson(c, l, pr) {
  const box = $('#content'); if (!box) return; const lp = pr.lessons[l.id], dl = (u, n) => `<a class="btn ghost sm" href="${u}" download="${esc(n || l.title)}">⬇ Download</a>`;
  A.manual = () => { completeLesson(c, l); const m = $('#manual-wrap'); if (m) m.innerHTML = manualBtn(c, l); };
  const manual = () => `<div id="manual-wrap">${manualBtn(c, l)}</div>`;
  let lastSave = 0; const savePos = (t, force) => { if (force || Date.now() - lastSave > 4000) { lp.pos = t; lastSave = Date.now(); save('progress', pr); } };
  const src = l.fileId ? await fileURL(l.fileId) : l.url, file = l.fileId ? await getFile(l.fileId) : null, k = l.kind;
  try {
    if (k === 'video' || k === 'audio') {
      const tag = k === 'video' ? 'video' : 'audio'; box.innerHTML = `<${tag} id="mv" controls playsinline preload="metadata" src="${esc(src)}" ${k === 'audio' ? 'style="background:none;margin:20px 0"' : ''}></${tag}><div class="pad sm muted" id="vmsg">${lp.pos > 5 ? '⏱ Resuming from ' + Math.floor(lp.pos / 60) + ':' + String(Math.floor(lp.pos % 60)).padStart(2, '0') : ''}</div><div id="manual-wrap" class="hide">${manualBtn(c, l)}</div>`;
      const v = $('#mv'); v.addEventListener('loadedmetadata', () => { if (lp.pos > 2 && lp.pos < v.duration - 3 && !lp.done) v.currentTime = lp.pos; });
      v.addEventListener('timeupdate', () => { savePos(v.currentTime); if (v.duration && v.currentTime / v.duration >= .97 && !lp.done) { completeLesson(c, l, { pos: 0 }); } });
      v.addEventListener('pause', () => savePos(v.currentTime, true)); v.addEventListener('ended', () => { if (!lp.done) completeLesson(c, l, { pos: 0 }); else { lp.pos = 0; save('progress', pr); } });
      v.addEventListener('error', () => { $('#vmsg').innerHTML = `⚠️ This browser can't play this file format (${esc(file?.name || '')}). ${src ? dl(src, file?.name) : ''}`; $('#manual-wrap').classList.remove('hide'); });
      CLEANUP = () => { if (v.currentTime) savePos(v.currentTime, true); };
    } else if (k === 'youtube') {
      const id = ytId(l.url); if (!id) { box.innerHTML = `<div class="pad">Invalid YouTube link.</div>`; return; }
      box.innerHTML = `<div class="yt"><div id="ytp"></div></div><div id="manual-wrap" class="hide">${manualBtn(c, l)}</div>`;
      try {
        await loadYT(); let timer, yp; yp = new YT.Player('ytp', { videoId: id, width: '100%', height: '100%', playerVars: { start: lp.done ? 0 : Math.floor(lp.pos || 0), rel: 0, playsinline: 1 }, events: { onStateChange: e => { if (e.data === 0 && !lp.done) completeLesson(c, l, { pos: 0 }); if (e.data === 1) { clearInterval(timer); timer = setInterval(() => { try { const t = yp.getCurrentTime(), d = yp.getDuration(); savePos(t, true); if (d && t / d >= .97 && !lp.done) completeLesson(c, l, { pos: 0 }); } catch (x) { } }, 4000); } if (e.data === 2) { try { savePos(yp.getCurrentTime(), true); } catch (x) { } } } } });
        CLEANUP = () => { clearInterval(timer); try { savePos(yp.getCurrentTime(), true); yp.destroy(); } catch (x) { } };
      } catch (e) { box.innerHTML = `<div class="yt"><iframe class="yt" src="https://www.youtube.com/embed/${id}?rel=0&start=${Math.floor(lp.pos || 0)}" allowfullscreen allow="autoplay; encrypted-media"></iframe></div><div class="pad sm muted">Automatic tracking unavailable — mark complete after watching.</div>${manual()}`; }
    } else if (k === 'image') box.innerHTML = `<img src="${esc(src)}" alt="${esc(l.title)}">${manual()}`;
    else if (k === 'pdf') box.innerHTML = `<iframe class="frame" src="${esc(src)}"></iframe><div class="pad row wrap"><a class="btn ghost sm" target="_blank" href="${esc(src)}">↗ Open full screen</a>${dl(src, file?.name)}</div>${manual()}`;
    else if (k === 'html') box.innerHTML = `<iframe class="frame" ${l.fileId ? `sandbox="allow-scripts allow-forms allow-popups" src="${esc(src)}"` : `src="${esc(src)}"`}></iframe>${manual()}`;
    else if (k === 'ppt') {
      const isX = file && /\.pptx$/i.test(file.name); box.innerHTML = '<div class="empty">Loading slides…</div>';
      if (isX) { try { await renderPptx(file.blob, box, lp.pos || 0, (i, n) => { savePos(i, true); if (i === n - 1 && !lp.done) completeLesson(c, l, { pos: 0 }); }); box.insertAdjacentHTML('beforeend', `<div class="pad row wrap">${dl(src, file.name)}</div>${manual()}`); return; } catch (e) { console.warn(e); } }
      if (!l.fileId && l.url) box.innerHTML = `<iframe class="frame" src="https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(l.url)}"></iframe>${manual()}`;
      else box.innerHTML = `<div class="pad"><p>📊 <b>${esc(file?.name || l.title)}</b></p><p class="muted sm">This presentation format can't be previewed in the browser. Download it, review it, then mark complete. (Tip: save as .pptx or export to PDF for in-app viewing.)</p>${src ? dl(src, file?.name) : ''}</div>${manual()}`;
    } else if (k === 'doc') box.innerHTML = `<div class="pad"><p>📄 <b>${esc(file?.name || l.title)}</b> ${file ? `<span class="muted sm">(${fmtSize(file.size)})</span>` : ''}</p>${src ? `<a class="btn ghost" ${l.fileId ? `download="${esc(file.name)}"` : 'target="_blank"'} href="${esc(src)}">⬇ Open / Download</a>` : ''}</div>${manual()}`;
    else if (k === 'link') box.innerHTML = `<div class="pad"><p class="muted">External resource:</p><a class="btn" target="_blank" rel="noopener" href="${esc(l.url)}">↗ Open link</a></div>${manual()}`;
    else if (k === 'text') box.innerHTML = `<div class="pad" style="white-space:pre-wrap;line-height:1.6">${esc(l.text || '').replace(/(https?:\/\/[^\s<]+)/g, '<a target="_blank" rel="noopener" href="$1">$1</a>')}</div>${manual()}`;
    else if (k === 'zip') mountPackage(c, l, pr, box, manual);
    else if (k === 'quiz') mountQuiz(c, l, pr, box);
  } catch (e) { console.error(e); box.innerHTML = `<div class="pad">⚠️ Could not load this content: ${esc(e.message)}</div>${manual()}`; }
}
function mountPackage(c, l, pr, box, manual) {
  if (!('serviceWorker' in navigator) || !navigator.serviceWorker.controller) { box.innerHTML = `<div class="pad">This package needs the app's offline engine. <button class="btn sm" onclick="location.reload()">Reload app</button><p class="sm muted">(Serve the app over https/localhost; the first load activates it.)</p></div>`; return; }
  const lp = pr.lessons[l.id], u = me(); lp.scorm = lp.scorm || { kv: {} }; const kv = lp.scorm.kv;
  const def = { 'cmi.core.student_name': u.name, 'cmi.core.student_id': u.empId || u.id, 'cmi.learner_name': u.name, 'cmi.learner_id': u.empId || u.id, 'cmi.core.credit': 'credit', 'cmi.credit': 'credit', 'cmi.core.lesson_mode': 'normal', 'cmi.mode': 'normal', 'cmi.core.total_time': '0000:00:00', 'cmi.total_time': 'PT0S' };
  let err = '0', inited = false;
  const done = () => { const s12 = kv['cmi.core.lesson_status'], c04 = kv['cmi.completion_status'], s04 = kv['cmi.success_status']; return ['completed', 'passed'].includes(s12) || c04 === 'completed' || s04 === 'passed'; };
  const score = () => { const r = kv['cmi.core.score.raw'] ?? kv['cmi.score.raw']; if (r !== undefined && r !== '' && !isNaN(+r)) return +r; const s = kv['cmi.score.scaled']; return s !== undefined && s !== '' ? Math.round(+s * 100) : undefined; };
  const commit = () => { const sc = score(); if (done() && !lp.done) completeLesson(c, l, sc !== undefined ? { score: sc } : {}); else { if (sc !== undefined) lp.score = sc; save('progress', pr); } return 'true'; };
  const get = k => { err = '0'; if (k === 'cmi.core.entry' || k === 'cmi.entry') return kv['cmi.suspend_data'] ? 'resume' : 'ab-initio'; if (k in kv) return String(kv[k]); if (k in def) return def[k]; if (k.endsWith('_children') || k.endsWith('_count')) return ''; return ''; };
  const set = (k, v) => { err = '0'; kv[k] = String(v); return 'true'; };
  window.API = { LMSInitialize: () => { inited = true; err = '0'; return 'true'; }, LMSFinish: () => { commit(); return 'true'; }, LMSGetValue: get, LMSSetValue: set, LMSCommit: commit, LMSGetLastError: () => err, LMSGetErrorString: () => 'No error', LMSGetDiagnostic: () => '' };
  window.API_1484_11 = { Initialize: () => { inited = true; return 'true'; }, Terminate: () => { commit(); return 'true'; }, GetValue: get, SetValue: set, Commit: commit, GetLastError: () => err, GetErrorString: () => 'No error', GetDiagnostic: () => '' };
  box.innerHTML = `<iframe class="frame" id="pkgf" allow="autoplay; fullscreen" src="${pkgURL(l)}"></iframe>${l.scorm ? `<div class="pad sm muted">SCORM ${l.scorm} package · progress is tracked automatically</div>` : manual()}`;
  CLEANUP = () => { commit(); delete window.API; delete window.API_1484_11; };
}
function mountQuiz(c, l, pr, box) {
  const q = l.quiz || { questions: [], pass: S.settings.passMark }, lp = pr.lessons[l.id];
  if (!q.questions.length) { box.innerHTML = '<div class="pad">This quiz has no questions yet.</div>'; return; }
  const draw = () => box.innerHTML = `<div class="pad"><p class="muted sm">Pass mark: ${q.pass}%${lp.score != null ? ` · Best score: ${lp.score}%` : ''}${lp.attempts ? ` · Attempts: ${lp.attempts}` : ''}</p><form data-form="quiz">${q.questions.map((x, i) => `<div class="q"><div class="b">${i + 1}. ${esc(x.q)}</div>${x.opts.map((o, j) => `<label><input type="radio" name="q${i}" value="${j}" required> ${esc(o)}</label>`).join('')}</div>`).join('')}<button class="btn block">Submit answers</button></form></div>`;
  F.quiz = (f, fd) => {
    let ok = 0; q.questions.forEach((x, i) => { if (+fd.get('q' + i) === x.ans) ok++; }); const sc = Math.round(ok / q.questions.length * 100), pass = sc >= q.pass;
    lp.attempts = (lp.attempts || 0) + 1; lp.score = Math.max(lp.score || 0, sc);
    box.innerHTML = `<div class="pad" style="text-align:center"><div style="font-size:44px">${pass ? '🎉' : '😕'}</div><h2>${sc}% — ${pass ? 'Passed!' : 'Not passed'}</h2><p class="muted">${ok} of ${q.questions.length} correct. Pass mark ${q.pass}%.</p>${pass ? '' : '<button class="btn" data-act="retryQuiz">Try again</button>'}</div>`;
    if (pass) completeLesson(c, l, { score: lp.score }); else save('progress', pr);
  };
  A.retryQuiz = draw; draw();
}

/* ---- certificates ---- */
const certCfg = c => ({ name: c.name, course: c.course, empId: c.empId, date: fmtDate(c.date), certNo: c.certNo, score: c.score, color: S.settings.certColor, org: S.settings.orgName, dept: S.settings.deptName, signatory: S.settings.signatory, signatoryTitle: S.settings.signatoryTitle, sealLabel: S.settings.sealLabel });
V.certs = () => {
  const u = me(), L = S.certs.filter(c => c.userId === u.id).sort((a, b) => b.issuedAt.localeCompare(a.issuedAt));
  return shell('My Certificates', L.length ? L.map(c => `<div class="card click" data-act="open" data-to="#/cert/${c.id}"><div class="row"><div class="thumb">🎓</div><div class="col"><div class="b">${esc(c.course)}</div><div class="sm muted">${fmtDate(c.date)} · ${esc(c.certNo)} · ${esc(c.score)}</div></div><span class="pill ok">View</span></div></div>`).join('') : empty('Complete a course 100% to earn your certificate.', '🎓'));
};
V.cert = id => {
  const c = S.certs.find(x => x.id === id), u = me(); if (!c || (c.userId !== u.id && !isAdmin())) return shell('Certificate', empty('Certificate not found'), { back: 1 });
  AFTER = async () => { const cv = $('#cv'); if (cv) await drawCertificate(cv, certCfg(c), LOGO); };
  return shell('Certificate', `<canvas id="cv" class="cert" width="1600" height="900"></canvas><div class="row wrap" style="margin-top:12px"><button class="btn" data-act="certPdf" data-id="${c.id}">⬇ Download PDF</button><button class="btn ghost" data-act="certPng" data-id="${c.id}">⬇ PNG image</button></div><p class="sm muted">Certificate ID <b>${esc(c.certNo)}</b> · issued to ${esc(c.name)} on ${fmtDate(c.date)}. Anyone can verify it from the login page.</p>`, { back: 1, nav: 'certs' });
};
A.certPdf = async d => { const c = S.certs.find(x => x.id === d.id), cv = document.createElement('canvas'); await drawCertificate(cv, certCfg(c), LOGO); download(`Certificate-${c.certNo}.pdf`, canvasToPdf(cv)); };
A.certPng = async d => { const c = S.certs.find(x => x.id === d.id), cv = document.createElement('canvas'); await drawCertificate(cv, certCfg(c), LOGO); cv.toBlob(b => download(`Certificate-${c.certNo}.png`, b)); };
V.verify = () => `<div style="flex:1;padding:20px;max-width:480px;margin:auto;width:100%"><h2>Verify certificate</h2><form class="card" data-form="verify">${field('Certificate ID', '<input name="n" placeholder="KTC-CERT-XXXXXX" required>')}<button class="btn block">Verify</button><div id="vres" style="margin-top:12px"></div></form><a href="#/">‹ Back to sign in</a></div>`;
F.verify = (f, fd) => { const c = S.certs.find(x => x.certNo.toLowerCase() === fd.get('n').trim().toLowerCase()); $('#vres').innerHTML = c ? `<div class="pill ok" style="display:block;padding:10px">✅ Valid certificate<br><b>${esc(c.name)}</b> completed <b>${esc(c.course)}</b> on ${fmtDate(c.date)} (${esc(c.score)})</div>` : `<div class="pill bad" style="display:block;padding:10px">❌ No certificate found with that ID</div>`; };

/* ---- profile ---- */
V.profile = () => {
  const u = me();
  return shell('Profile', `<div class="card"><div class="row"><div class="thumb">👤</div><div class="col"><div class="b" style="font-size:18px">${esc(u.name)}</div><div class="muted sm">${esc(u.email)} · ${ROLE[u.role]}${u.empId ? ' · ID ' + esc(u.empId) : ''}</div></div></div></div>
  <form class="card" data-form="profile"><h3 style="margin-top:0">Edit details</h3>${field('Full name', `<input name="name" value="${esc(u.name)}" required>`)}${field('Phone', `<input name="phone" value="${esc(u.phone || '')}">`)}<button class="btn">Save</button></form>
  <form class="card" data-form="chpw"><h3 style="margin-top:0">Change password</h3>${field('Current password', '<input name="old" type="password" required>')}${field('New password', '<input name="p1" type="password" minlength="6" required>')}<button class="btn">Update password</button></form>
  ${isAdmin() ? `<button class="btn ghost block" data-act="switchMode" style="margin-bottom:10px">${mode() === 'admin' ? '👤 Switch to Learner view' : '🛠 Switch to Admin view'}</button>` : ''}<button class="btn danger block" data-act="logout">Sign out</button>`);
};
F.profile = async (f, fd) => { const u = me(); u.name = fd.get('name').trim(); u.phone = fd.get('phone').trim(); await save('users', u); bc.postMessage('sync'); toast('Profile saved', 'ok'); };
F.chpw = async (f, fd) => { const u = me(); if (await hashPw(fd.get('old')) !== u.pwHash) return toast('Current password is wrong', 'bad'); u.pwHash = await hashPw(fd.get('p1')); await save('users', u); f.reset(); toast('Password changed', 'ok'); };

/* ---- boot ---- */
const SUPER_ID = 'learning@admin', SUPER_PW = 'Learning@admin';
async function seed() {
  // one-time cleanup of the old demo data from earlier builds
  const old = S.users.find(u => u.email === 'super@lms.app');
  if (old) {
    for (const u of S.users.filter(u => ['admin@lms.app', 'user@lms.app'].includes(u.email))) { purgeUserData(u.id); await remove('users', u.id); }
    const demo = S.courses.find(c => c.title === 'Welcome to the Learning Hub'); if (demo) { S.assignments.filter(a => a.courseId === demo.id).forEach(a => remove('assignments', a.id)); await remove('courses', demo.id); }
    old.email = SUPER_ID; old.empId = ''; old.pwHash = await hashPw(SUPER_PW); old.mustChange = false; await save('users', old);
  }
  if (S.users.length) return;
  await save('users', { id: uid('u'), name: 'Super Admin', email: SUPER_ID, role: 'superadmin', empId: '', dept: 'Administration', phone: '', status: 'active', mustChange: false, pwHash: await hashPw(SUPER_PW), createdAt: new Date().toISOString() });
}
(async function boot() {
  await DB.open(); await loadAll(); await seed(); await refreshLogo(); applyTheme();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) navigator.serviceWorker.register('sw.js').catch(() => { });
  render();
})();
